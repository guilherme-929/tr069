export declare class DiscoveryEngineModule {
}

"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var AlertsService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.AlertsService = void 0;
const common_1 = require("@nestjs/common");
const schedule_1 = require("@nestjs/schedule");
const prisma_service_1 = require("../common/prisma.service");
const websocket_gateway_1 = require("../websocket/websocket.gateway");
let AlertsService = AlertsService_1 = class AlertsService {
    constructor(prisma, ws) {
        this.prisma = prisma;
        this.ws = ws;
        this.logger = new common_1.Logger(AlertsService_1.name);
    }
    async findAll(tenantId, query) {
        const page = query.page || 1;
        const limit = query.limit || 20;
        const skip = (page - 1) * limit;
        const where = { tenantId };
        if (query.resolved === 'true')
            where.resolved = true;
        if (query.resolved === 'false')
            where.resolved = false;
        if (query.severity)
            where.severity = query.severity;
        const [data, total] = await Promise.all([
            this.prisma.alert.findMany({
                where, skip, take: limit, orderBy: { createdAt: 'desc' },
                include: { device: { select: { serial: true, modelName: true } } },
            }),
            this.prisma.alert.count({ where }),
        ]);
        return { data, total, page, limit, totalPages: Math.ceil(total / limit) };
    }
    async resolve(id) {
        return this.prisma.alert.update({
            where: { id },
            data: { resolved: true },
        });
    }
    async create(data) {
        const alert = await this.prisma.alert.create({ data });
        this.ws.broadcast('alert:new', alert);
        return alert;
    }
    async checkOfflineDevices() {
        const now = Date.now();
        const fiveMinutesAgo = new Date(now - 5 * 60 * 1000);
        const oneHourAgo = new Date(now - 60 * 60 * 1000);
        const oneDayAgo = new Date(now - 24 * 60 * 60 * 1000);
        const offlineDevices = await this.prisma.device.findMany({
            where: {
                status: 'ONLINE',
                lastContact: { lt: fiveMinutesAgo },
            },
        });
        for (const device of offlineDevices) {
            await this.prisma.device.update({
                where: { id: device.id },
                data: { status: 'OFFLINE' },
            });
            const lastContactTime = device.lastContact?.getTime() || 0;
            const elapsed = now - lastContactTime;
            const severity = elapsed > 24 * 60 * 60 * 1000 ? 'CRITICAL'
                : elapsed > 60 * 60 * 1000 ? 'WARNING'
                    : 'WARNING';
            await this.create({
                type: 'DEVICE_OFFLINE',
                severity,
                title: `Device ${device.serial} went offline`,
                message: `Last contact: ${device.lastContact}. Elapsed: ${Math.round(elapsed / 60000)} min`,
                deviceId: device.id,
                tenantId: device.tenantId,
            });
        }
        const criticalThreshold = new Date(now - 24 * 60 * 60 * 1000);
        const existingOfflineAlerts = await this.prisma.alert.findMany({
            where: {
                type: 'DEVICE_OFFLINE',
                resolved: false,
                severity: 'WARNING',
                createdAt: { lt: criticalThreshold },
            },
            include: { device: true },
        });
        for (const alert of existingOfflineAlerts) {
            if (!alert.device)
                continue;
            const elapsed = now - (alert.device.lastContact?.getTime() || alert.createdAt.getTime());
            if (elapsed > 24 * 60 * 60 * 1000) {
                await this.prisma.alert.update({
                    where: { id: alert.id },
                    data: { severity: 'CRITICAL', title: `[CRITICAL] Device ${alert.device.serial} offline > 24h` },
                });
                this.ws.broadcast('alert:update', { id: alert.id, severity: 'CRITICAL' });
            }
        }
        const neverConnectedThreshold = new Date(now - 30 * 60 * 1000);
        const neverConnected = await this.prisma.device.findMany({
            where: {
                lastContact: null,
                createdAt: { lt: neverConnectedThreshold },
            },
        });
        for (const device of neverConnected) {
            const existingAlert = await this.prisma.alert.findFirst({
                where: { deviceId: device.id, type: 'DEVICE_OFFLINE', resolved: false, message: { contains: 'never connected' } },
            });
            if (!existingAlert) {
                await this.create({
                    type: 'DEVICE_OFFLINE',
                    severity: 'WARNING',
                    title: `Device ${device.serial} never connected`,
                    message: `Device created ${device.createdAt.toISOString()} but never connected to ACS`,
                    deviceId: device.id,
                    tenantId: device.tenantId,
                });
            }
        }
    }
    async checkOldFirmware() {
        const devices = await this.prisma.device.findMany({
            where: { firmware: { status: { not: 'LATEST' } } },
            include: { firmware: true },
        });
        for (const device of devices) {
            if (device.firmware && device.firmware.status !== 'LATEST') {
                await this.create({
                    type: 'OLD_FIRMWARE',
                    severity: 'INFO',
                    title: `Device ${device.serial} has outdated firmware`,
                    message: `Current: ${device.firmwareVersion}`,
                    deviceId: device.id,
                    tenantId: device.tenantId,
                });
            }
        }
    }
};
exports.AlertsService = AlertsService;
__decorate([
    (0, schedule_1.Cron)('*/1 * * * *'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], AlertsService.prototype, "checkOfflineDevices", null);
__decorate([
    (0, schedule_1.Cron)('0 6 * * *'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], AlertsService.prototype, "checkOldFirmware", null);
exports.AlertsService = AlertsService = AlertsService_1 = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService,
        websocket_gateway_1.WebsocketGateway])
], AlertsService);
//# sourceMappingURL=alerts.service.js.map
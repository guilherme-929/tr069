"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ModelInspectCommand = void 0;
const nest_commander_1 = require("nest-commander");
const prisma_service_1 = require("../../common/prisma.service");
let ModelInspectCommand = class ModelInspectCommand extends nest_commander_1.CommandRunner {
    constructor(prisma) {
        super();
        this.prisma = prisma;
    }
    async run(args) {
        const [manufacturer, name] = args;
        const tenant = await this.prisma.tenant.findFirst({ where: { slug: 'default-isp' } })
            || await this.prisma.tenant.findFirst();
        if (!tenant) {
            console.error('No tenant found');
            return;
        }
        const model = await this.prisma.deviceModel.findFirst({
            where: { manufacturer, name, tenantId: tenant.id },
            include: { _count: { select: { devices: true, firmwares: true } } },
        });
        if (!model) {
            console.error(`Modelo "${manufacturer} / ${name}" não encontrado`);
            return;
        }
        const unsupported = model.unsupportedParameters || [];
        console.log(`\n=== ${model.manufacturer} ${model.name} ===`);
        console.log(`ID: ${model.id}`);
        console.log(`HW Version: ${model.hwVersion || 'N/A'}`);
        console.log(`Data Model: ${model.dataModel}`);
        console.log(`Dispositivos: ${model._count.devices}`);
        console.log(`Firmwares: ${model._count.firmwares}`);
        console.log(`Homologação: ${model.homologationStatus}`);
        console.log(`Homologado em: ${model.homologatedAt?.toISOString() || 'N/A'}`);
        console.log(`\nUnsupported Parameters (${unsupported.length}):`);
        if (unsupported.length === 0) {
            console.log('  (nenhum — modelo compatível)');
        }
        else {
            for (const p of unsupported) {
                console.log(`  ✗ ${p}`);
            }
        }
    }
};
exports.ModelInspectCommand = ModelInspectCommand;
exports.ModelInspectCommand = ModelInspectCommand = __decorate([
    (0, nest_commander_1.Command)({
        name: 'model:inspect',
        arguments: '<manufacturer> <name>',
        description: 'Mostra detalhes de um modelo cadastrado',
    }),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService])
], ModelInspectCommand);
//# sourceMappingURL=model-inspect.command.js.map
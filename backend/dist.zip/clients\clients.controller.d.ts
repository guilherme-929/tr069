import { ClientsService } from './clients.service';
export declare class ClientsController {
    private clientsService;
    constructor(clientsService: ClientsService);
    findAll(tenantId: string, query: any): Promise<{
        data: ({
            _count: {
                devices: number;
            };
        } & {
            id: string;
            tenantId: string;
            createdAt: Date;
            updatedAt: Date;
            name: string;
            document: string | null;
            contract: string | null;
            email: string | null;
            phone: string | null;
            plan: string | null;
            isActive: boolean;
        })[];
        total: number;
        page: number;
        limit: number;
        totalPages: number;
    }>;
    findOne(id: string): Promise<{
        devices: {
            id: string;
            tenantId: string;
            createdAt: Date;
            updatedAt: Date;
            serial: string;
            mac: string;
            manufacturer: string | null;
            modelName: string;
            firmwareVersion: string | null;
            hardwareVersion: string | null;
            status: import(".prisma/client").$Enums.DeviceStatus;
            ipAddress: string | null;
            wanIp: string | null;
            uptime: number;
            signal: number | null;
            lastInform: Date | null;
            lastContact: Date | null;
            modelId: string | null;
            clientId: string | null;
            firmwareId: string | null;
            tags: string[];
            parameters: import("@prisma/client/runtime/library").JsonValue | null;
            discoveredPaths: import("@prisma/client/runtime/library").JsonValue | null;
            parameterMeta: import("@prisma/client/runtime/library").JsonValue | null;
            connectionRequestUrl: string | null;
            connectionRequestUsername: string | null;
            connectionRequestPassword: string | null;
            acsPublicUrlOverride: string | null;
        }[];
    } & {
        id: string;
        tenantId: string;
        createdAt: Date;
        updatedAt: Date;
        name: string;
        document: string | null;
        contract: string | null;
        email: string | null;
        phone: string | null;
        plan: string | null;
        isActive: boolean;
    }>;
    create(data: any, tenantId: string): Promise<{
        id: string;
        tenantId: string;
        createdAt: Date;
        updatedAt: Date;
        name: string;
        document: string | null;
        contract: string | null;
        email: string | null;
        phone: string | null;
        plan: string | null;
        isActive: boolean;
    }>;
    update(id: string, data: any): Promise<{
        id: string;
        tenantId: string;
        createdAt: Date;
        updatedAt: Date;
        name: string;
        document: string | null;
        contract: string | null;
        email: string | null;
        phone: string | null;
        plan: string | null;
        isActive: boolean;
    }>;
    remove(id: string): Promise<{
        message: string;
    }>;
}

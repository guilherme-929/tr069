import { CommandRunner } from 'nest-commander';
import { PrismaService } from '../../common/prisma.service';
import { ProvisionsEngineService } from '../../scripts/provisions-engine.service';
export declare class ProvisionExecuteCommand extends CommandRunner {
    private prisma;
    private provisionsEngine;
    constructor(prisma: PrismaService, provisionsEngine: ProvisionsEngineService);
    parseEvent(val: string): string[];
    run(args: string[], options: {
        event?: string[];
    }): Promise<void>;
}

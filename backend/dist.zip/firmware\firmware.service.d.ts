import { PrismaService } from '../common/prisma.service';
export declare class FirmwareService {
    private prisma;
    constructor(prisma: PrismaService);
    findAll(tenantId: string, query: {
        page?: number;
        limit?: number;
        modelId?: string;
    }): Promise<{
        data: ({
            model: {
                id: string;
                description: string | null;
                tenantId: string;
                createdAt: Date;
                updatedAt: Date;
                name: string;
                manufacturer: string;
                hwVersion: string | null;
                dataModel: string;
                defaultParameters: import("@prisma/client/runtime/library").JsonValue | null;
                unsupportedParameters: import("@prisma/client/runtime/library").JsonValue | null;
                defaultAcsUrl: string | null;
                provisioningScript: string | null;
                homologationStatus: import(".prisma/client").$Enums.HomologationStatus;
                homologationNotes: string | null;
                homologatedAt: Date | null;
                homologatedBy: string | null;
            };
            _count: {
                devices: number;
            };
        } & {
            id: string;
            tenantId: string;
            createdAt: Date;
            updatedAt: Date;
            status: import(".prisma/client").$Enums.FirmwareStatus;
            modelId: string;
            version: string;
            changelog: string | null;
            fileName: string | null;
            fileSize: number | null;
            filePath: string | null;
        })[];
        total: number;
        page: number;
        limit: number;
        totalPages: number;
    }>;
    findOne(id: string): Promise<{
        model: {
            id: string;
            description: string | null;
            tenantId: string;
            createdAt: Date;
            updatedAt: Date;
            name: string;
            manufacturer: string;
            hwVersion: string | null;
            dataModel: string;
            defaultParameters: import("@prisma/client/runtime/library").JsonValue | null;
            unsupportedParameters: import("@prisma/client/runtime/library").JsonValue | null;
            defaultAcsUrl: string | null;
            provisioningScript: string | null;
            homologationStatus: import(".prisma/client").$Enums.HomologationStatus;
            homologationNotes: string | null;
            homologatedAt: Date | null;
            homologatedBy: string | null;
        };
    } & {
        id: string;
        tenantId: string;
        createdAt: Date;
        updatedAt: Date;
        status: import(".prisma/client").$Enums.FirmwareStatus;
        modelId: string;
        version: string;
        changelog: string | null;
        fileName: string | null;
        fileSize: number | null;
        filePath: string | null;
    }>;
    create(data: any, tenantId: string): Promise<{
        id: string;
        tenantId: string;
        createdAt: Date;
        updatedAt: Date;
        status: import(".prisma/client").$Enums.FirmwareStatus;
        modelId: string;
        version: string;
        changelog: string | null;
        fileName: string | null;
        fileSize: number | null;
        filePath: string | null;
    }>;
    update(id: string, data: any): Promise<{
        id: string;
        tenantId: string;
        createdAt: Date;
        updatedAt: Date;
        status: import(".prisma/client").$Enums.FirmwareStatus;
        modelId: string;
        version: string;
        changelog: string | null;
        fileName: string | null;
        fileSize: number | null;
        filePath: string | null;
    }>;
    remove(id: string): Promise<{
        message: string;
    }>;
}

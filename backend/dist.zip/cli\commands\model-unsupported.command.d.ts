import { CommandRunner } from 'nest-commander';
import { PrismaService } from '../../common/prisma.service';
export declare class ModelUnsupportedCommand extends CommandRunner {
    private prisma;
    constructor(prisma: PrismaService);
    parseAdd(val: string): string;
    parseClear(): boolean;
    parseTenant(val: string): string;
    run(args: string[], options: {
        add?: string;
        clear?: boolean;
        tenant?: string;
    }): Promise<void>;
    private resolveDefaultTenant;
}

import { CommandRunner } from 'nest-commander';
import { PrismaService } from '../../common/prisma.service';
import { DeclareService } from '../../discovery-engine/declare.service';
interface RefreshOptions {
    maxAge?: number;
}
export declare class DeviceRefreshCommand extends CommandRunner {
    private prisma;
    private declareService;
    constructor(prisma: PrismaService, declareService: DeclareService);
    parseMaxAge(val: string): number;
    run(passedParams: string[], options: RefreshOptions): Promise<void>;
}
export {};

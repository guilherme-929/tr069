import { LogsService } from './logs.service';
export declare class LogsController {
    private logsService;
    constructor(logsService: LogsService);
    findAll(tenantId: string, query: any): Promise<{
        data: ({
            user: {
                name: string;
                email: string;
            } | null;
        } & {
            id: string;
            tenantId: string;
            createdAt: Date;
            deviceId: string | null;
            entityId: string | null;
            action: string;
            entity: string;
            detail: string | null;
            metadata: import("@prisma/client/runtime/library").JsonValue | null;
            userId: string | null;
        })[];
        total: number;
        page: number;
        limit: number;
        totalPages: number;
    }>;
    export(tenantId: string, query: any): Promise<{
        id: string;
        tenantId: string;
        createdAt: Date;
        deviceId: string | null;
        entityId: string | null;
        action: string;
        entity: string;
        detail: string | null;
        metadata: import("@prisma/client/runtime/library").JsonValue | null;
        userId: string | null;
    }[]>;
}

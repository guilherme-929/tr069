"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var CwmpService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.CwmpService = void 0;
const common_1 = require("@nestjs/common");
const prisma_service_1 = require("../common/prisma.service");
const websocket_gateway_1 = require("../websocket/websocket.gateway");
const fast_xml_parser_1 = require("fast-xml-parser");
const scripts_service_1 = require("../scripts/scripts.service");
const config_service_1 = require("../system-config/config.service");
const devices_service_1 = require("../devices/devices.service");
let CwmpService = CwmpService_1 = class CwmpService {
    constructor(prisma, ws, scriptsService, configService, devicesService) {
        this.prisma = prisma;
        this.ws = ws;
        this.scriptsService = scriptsService;
        this.configService = configService;
        this.devicesService = devicesService;
        this.logger = new common_1.Logger(CwmpService_1.name);
        this.parser = new fast_xml_parser_1.XMLParser({
            ignoreAttributes: false,
            attributeNamePrefix: '@_',
            textNodeName: '#text',
        });
        this.builder = new fast_xml_parser_1.XMLBuilder({
            ignoreAttributes: false,
            attributeNamePrefix: '@_',
            format: true,
            suppressEmptyNode: true,
        });
        this.cachedTenantId = null;
        this.lastSerial = null;
    }
    async resolveTenantId() {
        if (this.cachedTenantId)
            return this.cachedTenantId;
        const tenant = await this.prisma.tenant.findFirst({ where: { slug: 'default-isp' } })
            || await this.prisma.tenant.findFirst();
        if (!tenant)
            throw new Error('No tenant found in database. Run seed first.');
        this.cachedTenantId = tenant.id;
        return tenant.id;
    }
    async handleCwmp(xmlString, serial, getSession, clientIp) {
        if (!xmlString || !xmlString.trim()) {
            if (this.lastSerial) {
                const device = await this.prisma.device.findUnique({ where: { serial: this.lastSerial } });
                if (device) {
                    const pending = await this.prisma.task.count({ where: { deviceId: device.id, status: 'PENDING' } });
                    if (pending > 0) {
                        return this.buildNextCommandResponse(device);
                    }
                }
            }
            return this.buildEmptySoapEnvelope();
        }
        if (serial)
            this.lastSerial = serial;
        try {
            const parsed = this.parser.parse(xmlString);
            const envelope = parsed['soap:Envelope'] || parsed['soapenv:Envelope'] || parsed['SOAP-ENV:Envelope'] || parsed['Envelope'];
            const body = envelope?.['soap:Body'] || envelope?.['soapenv:Body'] || envelope?.['SOAP-ENV:Body'] || envelope?.['Body'];
            if (!body) {
                return this.buildFaultResponse('Client', 'No SOAP body found');
            }
            const bodyKeys = Object.keys(body);
            if (body['cwmp:Inform'] || body['Inform']) {
                return await this.handleInform(body, serial, clientIp);
            }
            if (body['cwmp:TransferComplete'] || body['TransferComplete']) {
                return await this.handleTransferComplete(body);
            }
            if (body['cwmp:AutonomousTransferComplete'] || body['AutonomousTransferComplete']) {
                return await this.handleAutonomousTransferComplete(body);
            }
            if (body['cwmp:GetRPCMethods'] || body['GetRPCMethods']) {
                return this.buildGetRPCMethodsResponse();
            }
            if (body['cwmp:GetParameterValuesResponse'] || body['GetParameterValuesResponse']) {
                return await this.handleGetParameterValuesResponse(body);
            }
            if (body['cwmp:SetParameterValuesResponse'] || body['SetParameterValuesResponse']) {
                return await this.handleSetParameterValuesResponse(body);
            }
            if (body['cwmp:GetParameterNamesResponse'] || body['GetParameterNamesResponse']) {
                return await this.handleGetParameterNamesResponse(body);
            }
            if (body['cwmp:DownloadResponse'] || body['DownloadResponse']) {
                return await this.handleDownloadResponse(body);
            }
            if (body['cwmp:UploadResponse'] || body['UploadResponse']) {
                return await this.handleUploadResponse(body);
            }
            if (body['cwmp:RebootResponse'] || body['RebootResponse']) {
                return await this.handleRebootResponse(body);
            }
            if (body['cwmp:FactoryResetResponse'] || body['FactoryResetResponse']) {
                return await this.handleFactoryResetResponse(body);
            }
            if (body['SOAP-ENV:Fault'] || body['soap:Fault'] || body['Fault']) {
                const faultDetail = JSON.stringify(body['SOAP-ENV:Fault'] || body['soap:Fault'] || body['Fault']).slice(0, 500);
                this.logger.warn(`CPE returned Fault: ${faultDetail}`);
                if (this.lastSerial) {
                    const device = await this.prisma.device.findUnique({ where: { serial: this.lastSerial } });
                    if (device) {
                        const failedTasks = await this.prisma.task.findMany({
                            where: { deviceId: device.id, status: 'IN_PROGRESS' },
                            select: { id: true, type: true, payload: true, maxAttempts: true },
                        });
                        for (const ft of failedTasks) {
                            this.logger.warn(`[FAULT-DETAIL] Device=${device.serial} Task=${ft.id} Type=${ft.type} Payload=${JSON.stringify(ft.payload).slice(0, 300)}`);
                        }
                        await this.prisma.task.updateMany({
                            where: { deviceId: device.id, status: 'IN_PROGRESS' },
                            data: { status: 'FAILED', error: `CPE returned SOAP Fault: ${faultDetail.slice(0, 200)}` },
                        });
                        await this.prisma.event.create({
                            data: {
                                deviceId: device.id,
                                code: 'SOAP_FAULT',
                                message: `CPE returned Fault: ${faultDetail.slice(0, 200)}`,
                                data: { fault: faultDetail, failedTasks: failedTasks.map(t => ({ id: t.id, type: t.type })) },
                                tenantId: device.tenantId,
                            },
                        });
                        const isFault9814 = faultDetail.includes('9814') || faultDetail.includes('Parse xml');
                        if (isFault9814) {
                            const faultedTypes = [...new Set(failedTasks.map(t => t.type))];
                            for (const ft of faultedTypes) {
                                const cancelled = await this.prisma.task.updateMany({
                                    where: { deviceId: device.id, status: 'PENDING', type: ft },
                                    data: { status: 'CANCELLED', error: `Cancelled due to Fault 9814 on type ${ft}` },
                                });
                                if (cancelled.count > 0) {
                                    this.logger.warn(`[FAULT-9814] Cancelled ${cancelled.count} pending ${ft} tasks for ${device.serial}`);
                                }
                            }
                        }
                        const isFault9005 = faultDetail.includes('9005') || faultDetail.includes('Invalid parameter name');
                        if (isFault9005) {
                            for (const ft of failedTasks) {
                                const payload = (ft.payload || {});
                                if (ft.type === 'GetParameterValues' && Array.isArray(payload.names)) {
                                    if (payload.names.length > 1) {
                                        const half = Math.ceil(payload.names.length / 2);
                                        const split1 = payload.names.slice(0, half);
                                        const split2 = payload.names.slice(half);
                                        this.logger.warn(`[FAULT-9005] Splitting GPV task ${ft.id}: ${payload.names.length} names -> ${split1.length} + ${split2.length}`);
                                        for (const chunk of [split1, split2]) {
                                            await this.prisma.task.create({
                                                data: {
                                                    deviceId: device.id,
                                                    type: 'GetParameterValues',
                                                    status: 'PENDING',
                                                    payload: { names: chunk },
                                                    tenantId: device.tenantId,
                                                },
                                            });
                                        }
                                    }
                                    else if (payload.names.length === 1) {
                                        await this.markPathUnsupported(device.modelId, payload.names[0]);
                                    }
                                }
                                if ((ft.type === 'SetParameterValues' || ft.type === 'Provision') && payload.parameters) {
                                    const paramKeys = Object.keys(payload.parameters);
                                    if (paramKeys.length > 1) {
                                        const half = Math.ceil(paramKeys.length / 2);
                                        const split1 = paramKeys.slice(0, half);
                                        const split2 = paramKeys.slice(half);
                                        this.logger.warn(`[FAULT-9005] Splitting ${ft.type} task ${ft.id}: ${paramKeys.length} params -> ${split1.length} + ${split2.length}`);
                                        for (const chunk of [split1, split2]) {
                                            const chunkParams = {};
                                            for (const k of chunk)
                                                chunkParams[k] = payload.parameters[k];
                                            await this.prisma.task.create({
                                                data: {
                                                    deviceId: device.id,
                                                    type: ft.type,
                                                    status: 'PENDING',
                                                    payload: { parameters: chunkParams },
                                                    maxAttempts: ft.maxAttempts || 3,
                                                    tenantId: device.tenantId,
                                                },
                                            });
                                        }
                                    }
                                    else if (paramKeys.length === 1) {
                                        await this.markPathUnsupported(device.modelId, paramKeys[0]);
                                        this.logger.warn(`[FAULT-9005] Path "${paramKeys[0]}" marked as unsupported for model ${device.modelId || 'unknown'}`);
                                    }
                                }
                            }
                        }
                    }
                }
                return this.buildEmptySoapEnvelope();
            }
            this.logger.warn(`Unhandled CWMP method: ${bodyKeys.join(', ')}`);
            return this.buildEmptySoapEnvelope();
        }
        catch (error) {
            this.logger.error('Error handling CWMP:', error);
            return this.buildFaultResponse('Server', 'Internal server error');
        }
    }
    async handleInform(data, serialFromAuth, clientIp) {
        const inform = data?.['cwmp:Inform'] || data?.Inform;
        if (!inform)
            return this.buildFaultResponse('Client', 'Invalid Inform message');
        const deviceId = inform.DeviceId || {};
        const serial = serialFromAuth || deviceId?.SerialNumber || '';
        const mac = deviceId?.MACAddress || '';
        const manufacturer = deviceId?.Manufacturer || '';
        const oui = deviceId?.OUI || '';
        const modelName = deviceId?.ProductClass || '';
        const eventCodes = inform.Event?.EventStruct || [];
        const parameters = inform.ParameterList?.ParameterValueStruct || [];
        const events = Array.isArray(eventCodes) ? eventCodes : [eventCodes];
        const eventCodeStr = events.map((e) => e?.EventCode || '').join(' ');
        if (!serial) {
            this.logger.warn('Inform received without serial number');
            return this.buildFaultResponse('Client', 'Missing serial number');
        }
        if (eventCodeStr.includes('1 BOOT') || eventCodeStr.includes('BOOT')) {
            const recentBoot = await this.prisma.event.findFirst({
                where: { deviceId: serial, code: { contains: 'BOOT' } },
                orderBy: { createdAt: 'desc' },
            });
            if (recentBoot) {
                const elapsed = Date.now() - new Date(recentBoot.createdAt).getTime();
                if (elapsed < 60000) {
                    this.logger.warn(`[BOOT-DEBOUNCE] Ignoring BOOT from ${serial} — last BOOT was ${Math.round(elapsed / 1000)}s ago`);
                }
            }
        }
        let device = await this.prisma.device.findUnique({ where: { serial } });
        const paramMap = {};
        const paramList = Array.isArray(parameters) ? parameters : [parameters];
        for (const p of paramList) {
            if (p.Name) {
                paramMap[p.Name] = (p.Value && typeof p.Value === 'object' && !('#text' in p.Value)) ? '(hidden)' : (p.Value?.['#text'] ?? p.Value ?? '');
            }
        }
        const cleanClientIp = clientIp ? clientIp.replace(/^.*:/, '') : '';
        const privateIpRegex = /^(0\.0\.0\.0|\[::\]|localhost|127\.0\.0\.1|10\.|192\.168\.|172\.(1[6-9]|2[0-9]|3[0-1])\.|100\.(6[4-9]|[7-9][0-9]|1[0-1][0-9]|12[0-7])\.)/;
        const reportedIp = inform.DeviceId?.IPAddress
            || paramMap['Device.IP.Interface.1.IPv4Address']
            || paramMap['InternetGatewayDevice.WANDevice.1.WANConnectionDevice.1.WANPPPConnection.1.ExternalIPAddress']
            || paramMap['InternetGatewayDevice.WANDevice.1.WANConnectionDevice.1.WANIPConnection.1.ExternalIPAddress']
            || '';
        const ipAddress = (reportedIp && !privateIpRegex.test(reportedIp)) ? reportedIp : (cleanClientIp || reportedIp || '');
        const wanIp = cleanClientIp || reportedIp || '';
        const firmwareVersion = paramMap['Device.DeviceInfo.SoftwareVersion']
            || paramMap['InternetGatewayDevice.DeviceInfo.SoftwareVersion']
            || '';
        const hardwareVersion = paramMap['Device.DeviceInfo.HardwareVersion']
            || paramMap['InternetGatewayDevice.DeviceInfo.HardwareVersion']
            || '';
        const uptime = parseInt(paramMap['Device.DeviceInfo.UpTime'] || paramMap['InternetGatewayDevice.DeviceInfo.UpTime'] || '0', 10);
        let connectionRequestUrl = paramMap['InternetGatewayDevice.ManagementServer.ConnectionRequestURL']
            || paramMap['Device.ManagementServer.ConnectionRequestURL']
            || '';
        const wan1Ip = paramMap['InternetGatewayDevice.WANDevice.1.WANConnectionDevice.1.WANIPConnection.1.ExternalIPAddress']
            || paramMap['InternetGatewayDevice.WANDevice.1.WANConnectionDevice.1.WANPPPConnection.1.ExternalIPAddress']
            || '';
        if (wan1Ip && wan1Ip !== ipAddress && !privateIpRegex.test(wan1Ip)) {
            try {
                if (connectionRequestUrl) {
                    const urlObj = new URL(connectionRequestUrl);
                    if (privateIpRegex.test(urlObj.hostname) && !privateIpRegex.test(wan1Ip)) {
                        urlObj.hostname = wan1Ip;
                        connectionRequestUrl = urlObj.toString();
                    }
                }
            }
            catch (e) {
                if (connectionRequestUrl) {
                    if (connectionRequestUrl.includes('0.0.0.0')) {
                        connectionRequestUrl = connectionRequestUrl.replace('0.0.0.0', wan1Ip);
                    }
                    else if (connectionRequestUrl.includes('[::]')) {
                        connectionRequestUrl = connectionRequestUrl.replace('[::]', wan1Ip);
                    }
                }
            }
        }
        else if (connectionRequestUrl && (cleanClientIp || ipAddress)) {
            const targetIp = cleanClientIp || ipAddress;
            try {
                const urlObj = new URL(connectionRequestUrl);
                if (privateIpRegex.test(urlObj.hostname) && !privateIpRegex.test(targetIp)) {
                    urlObj.hostname = targetIp;
                    connectionRequestUrl = urlObj.toString();
                }
            }
            catch (e) {
                if (connectionRequestUrl.includes('0.0.0.0')) {
                    connectionRequestUrl = connectionRequestUrl.replace('0.0.0.0', targetIp);
                }
                else if (connectionRequestUrl.includes('[::]')) {
                    connectionRequestUrl = connectionRequestUrl.replace('[::]', targetIp);
                }
            }
        }
        if (device) {
            if (!device.modelId && manufacturer && modelName) {
                const model = await this.prisma.deviceModel.findFirst({
                    where: { manufacturer, name: modelName },
                });
                if (model)
                    device.modelId = model.id;
            }
            device = await this.prisma.device.update({
                where: { id: device.id },
                data: {
                    status: 'ONLINE',
                    mac: mac || device.mac,
                    ipAddress: ipAddress || device.ipAddress,
                    wanIp: wanIp || device.wanIp,
                    manufacturer: manufacturer || device.manufacturer,
                    modelName: modelName || device.modelName,
                    firmwareVersion: firmwareVersion || device.firmwareVersion,
                    uptime: uptime || device.uptime,
                    modelId: device.modelId,
                    lastInform: new Date(),
                    lastContact: new Date(),
                    parameters: {
                        ...device.parameters,
                        ...paramMap,
                        'Device.ManagementServer.ConnectionRequestURL': connectionRequestUrl
                            || device.parameters?.['Device.ManagementServer.ConnectionRequestURL']
                            || '',
                        'InternetGatewayDevice.ManagementServer.ConnectionRequestURL': connectionRequestUrl
                            || device.parameters?.['InternetGatewayDevice.ManagementServer.ConnectionRequestURL']
                            || '',
                    },
                    ...(connectionRequestUrl && { connectionRequestUrl }),
                },
            });
        }
        else {
            let modelId;
            if (manufacturer && modelName) {
                const model = await this.prisma.deviceModel.findFirst({
                    where: { manufacturer, name: modelName },
                });
                if (model) {
                    modelId = model.id;
                }
                else {
                    const fallback = await this.prisma.deviceModel.findFirst({
                        where: { manufacturer },
                        orderBy: { createdAt: 'desc' },
                    });
                    if (fallback)
                        modelId = fallback.id;
                }
            }
            device = await this.prisma.device.create({
                data: {
                    serial,
                    mac: mac || serial,
                    manufacturer,
                    modelName: modelName || 'Unknown',
                    modelId,
                    firmwareVersion,
                    hardwareVersion,
                    status: 'ONLINE',
                    ipAddress,
                    wanIp,
                    connectionRequestUrl: connectionRequestUrl || undefined,
                    lastInform: new Date(),
                    lastContact: new Date(),
                    parameters: paramMap,
                    tenantId: await this.resolveTenantId(),
                },
            });
        }
        await this.prisma.session.create({
            data: {
                deviceId: device.id,
                event: eventCodeStr,
                status: 'ACTIVE',
                data: { events, parameters: paramMap },
                tenantId: device.tenantId,
            },
        });
        await this.prisma.event.create({
            data: {
                deviceId: device.id,
                code: eventCodeStr,
                message: `Inform received from ${serial} (${manufacturer} ${modelName})`,
                data: { events, parameters: paramMap },
                tenantId: device.tenantId,
            },
        });
        this.ws.broadcast('device:inform', {
            deviceId: device.id,
            serial,
            manufacturer,
            modelName,
            status: 'ONLINE',
            event: eventCodeStr,
            timestamp: new Date(),
        });
        await this.prisma.log.create({
            data: {
                action: eventCodeStr.includes('BOOT') ? 'BOOT' : 'INFORM',
                entity: 'DEVICE',
                entityId: device.id,
                detail: `Inform from ${serial} (${manufacturer} ${modelName}) - events: ${eventCodeStr}`,
                deviceId: device.id,
                tenantId: device.tenantId,
            },
        });
        try {
            await this.devicesService.computeAndStoreVirtualParameters(device.id);
        }
        catch (err) {
            this.logger.warn(`[VP] Failed to compute virtual params for ${serial}: ${err.message}`);
        }
        const isNewDevice = !device?.createdAt || (Date.now() - new Date(device.createdAt).getTime() < 120000);
        const provisionedAt = device?.parameters?.__provisionedAt__;
        const provisionedElapsed = provisionedAt ? Date.now() - new Date(provisionedAt).getTime() : Infinity;
        const needsProvision = (!provisionedAt || isNewDevice) && provisionedElapsed > 3600000;
        const existingProvTask = await this.prisma.task.count({
            where: { deviceId: device.id, status: { in: ['PENDING', 'IN_PROGRESS'] }, type: 'Provision' },
        });
        const recentEvents = await this.prisma.event.count({
            where: {
                deviceId: device.id,
                createdAt: { gte: new Date(Date.now() - 300000) },
            },
        });
        const isRapidReconnect = !isNewDevice && recentEvents > 8;
        let homologationBlocked = false;
        if (needsProvision && device.modelId) {
            const model = await this.prisma.deviceModel.findUnique({ where: { id: device.modelId } });
            if (model && (model.homologationStatus === 'PENDING_REVIEW' || model.homologationStatus === 'IN_TESTING')) {
                const hasHomologTag = device.tags?.includes('homolog');
                if (!hasHomologTag) {
                    homologationBlocked = true;
                    this.logger.warn(`[HOMOLOG] Blocked auto-provision for ${serial} — model "${model.name}" status=${model.homologationStatus}`);
                }
            }
        }
        if (needsProvision && existingProvTask === 0 && !isRapidReconnect && !homologationBlocked) {
            const acsUrl = device.acsPublicUrlOverride
                || process.env.ACS_PUBLIC_URL
                || `http://${ipAddress || 'localhost'}:${process.env.ACS_PORT || '7547'}`;
            const expectedAcsUrl = `${acsUrl}/cwmp`;
            const informInterval = await this.configService.getValue('default', 'cwmp.inform.interval') || '300';
            const periodicInformEnable = await this.configService.getValue('default', 'device.default.periodicInformEnable') || 'true';
            let modelParams = {};
            let deviceDataModel = null;
            if (device.modelId) {
                const model = await this.prisma.deviceModel.findUnique({ where: { id: device.modelId } });
                if (model) {
                    deviceDataModel = model.dataModel;
                    if (model?.defaultParameters) {
                        modelParams = model.defaultParameters;
                    }
                }
            }
            if (!deviceDataModel) {
                const reportedParams = Object.keys(paramMap);
                const hasTR181 = reportedParams.some(k => k.startsWith('Device.'));
                const hasTR098 = reportedParams.some(k => k.startsWith('InternetGatewayDevice.'));
                deviceDataModel = hasTR181 && !hasTR098 ? 'TR-181'
                    : hasTR098 && !hasTR181 ? 'TR-098'
                        : null;
            }
            const isTR181 = deviceDataModel === 'TR-181';
            const isTR098 = deviceDataModel === 'TR-098';
            const provisionParams = {
                ...Object.fromEntries(Object.entries(modelParams).filter(([key]) => {
                    if (isTR181 && key.startsWith('InternetGatewayDevice.'))
                        return false;
                    if (isTR098 && key.startsWith('Device.'))
                        return false;
                    return true;
                })),
            };
            if (isTR181 || (!deviceDataModel)) {
                provisionParams['Device.ManagementServer.URL'] = expectedAcsUrl;
                provisionParams['Device.ManagementServer.PeriodicInformInterval'] = informInterval;
                provisionParams['Device.ManagementServer.PeriodicInformEnable'] = periodicInformEnable;
            }
            if (isTR098 || (!deviceDataModel)) {
                provisionParams['InternetGatewayDevice.ManagementServer.URL'] = expectedAcsUrl;
                provisionParams['InternetGatewayDevice.ManagementServer.PeriodicInformInterval'] = informInterval;
                provisionParams['InternetGatewayDevice.ManagementServer.PeriodicInformEnable'] = periodicInformEnable;
            }
            this.logger.log(`[PROVISION] Auto-provisioning device ${serial} (model: ${device.modelName}, dataModel: ${deviceDataModel || 'unknown'}, new: ${isNewDevice})`);
            const tr098Params = Object.fromEntries(Object.entries(provisionParams).filter(([k]) => k.startsWith('InternetGatewayDevice.')));
            const tr181Params = Object.fromEntries(Object.entries(provisionParams).filter(([k]) => k.startsWith('Device.')));
            const otherParams = Object.fromEntries(Object.entries(provisionParams).filter(([k]) => !k.startsWith('InternetGatewayDevice.') && !k.startsWith('Device.')));
            const tasksToCreate = [];
            if (deviceDataModel || Object.keys(tr098Params).length === 0 || Object.keys(tr181Params).length === 0) {
                tasksToCreate.push(provisionParams);
            }
            else {
                if (Object.keys(tr098Params).length > 0) {
                    tasksToCreate.push({ ...otherParams, ...tr098Params });
                }
                if (Object.keys(tr181Params).length > 0) {
                    tasksToCreate.push({ ...otherParams, ...tr181Params });
                }
                this.logger.log(`[PROVISION] Split into ${tasksToCreate.length} namespace-specific tasks for ${serial}`);
            }
            for (const params of tasksToCreate) {
                await this.prisma.task.create({
                    data: {
                        deviceId: device.id,
                        type: 'Provision',
                        status: 'PENDING',
                        payload: { parameters: params },
                        tenantId: device.tenantId,
                    },
                });
            }
            const currentParams = device.parameters || {};
            await this.prisma.device.update({
                where: { id: device.id },
                data: {
                    parameters: { ...currentParams, __provisionedAt__: new Date().toISOString() },
                },
            });
        }
        else if (isRapidReconnect) {
            this.logger.warn(`[RAPID-RECONNECT] Device ${serial} skipped provisioning — ${recentEvents} events in last 5min`);
            const existingAlert = await this.prisma.alert.findFirst({
                where: {
                    deviceId: device.id,
                    type: 'ACS_SESSION_LOST',
                    resolved: false,
                },
            });
            if (!existingAlert) {
                await this.prisma.alert.create({
                    data: {
                        deviceId: device.id,
                        type: 'ACS_SESSION_LOST',
                        severity: 'WARNING',
                        title: `Rapid reconnect: ${serial}`,
                        message: `Rapid reconnect loop detected: ${recentEvents} events in 5min`,
                        tenantId: device.tenantId,
                    },
                });
            }
        }
        const params = device.parameters || {};
        const discovered = params.__discovered__ || {};
        const hasDiscovery = (discovered._leaves?.length || 0) > 0;
        const deviceAge = device.createdAt ? Date.now() - new Date(device.createdAt).getTime() : Infinity;
        const shouldDiscover = !hasDiscovery && (eventCodeStr.includes('BOOT') || deviceAge > 120000);
        if (shouldDiscover) {
            const existingDiscTask = await this.prisma.task.count({
                where: { deviceId: device.id, type: 'GetParameterNames', status: { in: ['PENDING', 'IN_PROGRESS'] } },
            });
            if (existingDiscTask === 0) {
                this.logger.log(`[DISCOVERY] Auto-starting parameter discovery for ${serial} (hasParams=${hasDiscovery}, age=${Math.round(deviceAge / 1000)}s)`);
                const currentParams = device.parameters || {};
                await this.prisma.device.update({
                    where: { id: device.id },
                    data: {
                        parameters: { ...currentParams, __discovered__: { _objects: [], _leaves: [], _values: {}, _writable: {} } },
                    },
                });
                await this.prisma.task.create({
                    data: {
                        deviceId: device.id,
                        type: 'GetParameterNames',
                        status: 'PENDING',
                        payload: { parameterPath: '', nextLevel: true },
                        tenantId: device.tenantId,
                    },
                });
            }
        }
        try {
            const channel = eventCodeStr.includes('BOOTSTRAP') ? 'bootstrap'
                : eventCodeStr.includes('BOOT') ? 'default'
                    : 'inform';
            await this.scriptsService.executePresets(device.tenantId, device.id, channel, device);
            const provisions = await this.scriptsService.getScriptsForChannel(device.tenantId, channel);
            for (const prov of provisions) {
                if (this.scriptsService.evaluatePrecondition(prov.precondition, device)) {
                    this.logger.log(`Executing provision "${prov.name}" for device ${serial} (channel: ${channel})`);
                    await this.scriptsService.executeScript(prov.id, device.id, device.tenantId);
                }
            }
        }
        catch (err) {
            this.logger.error(`Error executing presets for device ${serial}: ${err.message}`);
        }
        const pendingCount = await this.prisma.task.count({
            where: { deviceId: device.id, status: 'PENDING' },
        });
        if (pendingCount > 0) {
            this.logger.log(`Device ${serial} has ${pendingCount} pending tasks after Inform`);
        }
        return this.buildInformResponseWithTasks(device);
    }
    async handleTransferComplete(data) {
        const tc = data?.['cwmp:TransferComplete'] || data?.TransferComplete;
        if (!tc)
            return this.buildEmptySoapEnvelope();
        const commandKey = tc?.CommandKey || '';
        const fault = tc?.Fault || { FaultCode: '0', FaultString: '' };
        const faultCode = fault?.FaultCode || '0';
        this.logger.log(`[CWMP-EVENT] TransferComplete: commandKey=${commandKey}, faultCode=${faultCode}, faultString=${fault?.FaultString || ''}`);
        if (commandKey) {
            await this.prisma.task.updateMany({
                where: { id: commandKey },
                data: {
                    status: faultCode === '0' ? 'COMPLETED' : 'FAILED',
                    result: { faultCode: faultCode, faultString: fault?.FaultString },
                },
            });
        }
        if (this.lastSerial) {
            const device = await this.prisma.device.findUnique({ where: { serial: this.lastSerial } });
            if (device) {
                await this.prisma.event.create({
                    data: {
                        deviceId: device.id,
                        code: '7 TRANSFER COMPLETE',
                        message: `Transfer ${faultCode === '0' ? 'completed' : 'failed'}: commandKey=${commandKey}, fault=${faultCode} ${fault?.FaultString || ''}`,
                        data: { commandKey, faultCode, faultString: fault?.FaultString },
                        tenantId: device.tenantId,
                    },
                });
                await this.prisma.log.create({
                    data: {
                        action: 'TRANSFER_COMPLETE',
                        entity: 'DEVICE',
                        entityId: device.id,
                        detail: `Transfer ${faultCode === '0' ? 'completed' : 'failed'} for ${device.serial}: commandKey=${commandKey}`,
                        deviceId: device.id,
                        tenantId: device.tenantId,
                    },
                });
            }
        }
        return this.buildSoapResponse('TransferCompleteResponse', {});
    }
    async handleAutonomousTransferComplete(data) {
        return this.buildSoapResponse('AutonomousTransferCompleteResponse', {});
    }
    async handleGetParameterValuesResponse(data) {
        const response = data?.['cwmp:GetParameterValuesResponse'] || data?.GetParameterValuesResponse;
        const paramList = response?.ParameterList?.ParameterValueStruct || [];
        const params = Array.isArray(paramList) ? paramList : [paramList];
        const paramMap = {};
        for (const p of params) {
            if (p.Name) {
                paramMap[p.Name] = (p.Value && typeof p.Value === 'object' && !('#text' in p.Value)) ? '(hidden)' : (p.Value?.['#text'] ?? p.Value ?? '');
            }
        }
        this.logger.log(`[GPV-RESP] lastSerial=${this.lastSerial} names=${Object.keys(paramMap).join('|') || '(empty/Fault)'} cmdKey=${response?.CommandKey || '-'} fault=${data?.['soap:Fault'] ? JSON.stringify(data['soap:Fault']).slice(0, 200) : (data?.Fault ? JSON.stringify(data.Fault).slice(0, 200) : 'none')}`);
        if (Object.keys(paramMap).length === 0 || !this.lastSerial)
            return this.buildEmptySoapEnvelope();
        const device = await this.prisma.device.findUnique({
            where: { serial: this.lastSerial },
        });
        if (device) {
            const currentParams = device.parameters || {};
            const discovered = currentParams.__discovered__ || {};
            const updatedParams = { ...currentParams };
            const updatedValues = { ...(discovered._values || {}), ...paramMap };
            for (const [key, val] of Object.entries(paramMap)) {
                updatedParams[key] = val;
            }
            updatedParams.__discovered__ = { ...discovered, _values: updatedValues };
            let connectionRequestUrl = paramMap['InternetGatewayDevice.ManagementServer.ConnectionRequestURL']
                || paramMap['Device.ManagementServer.ConnectionRequestURL'];
            if (connectionRequestUrl) {
                const ipAddress = device.ipAddress;
                if (ipAddress) {
                    const privateIpRegex = /^(0\.0\.0\.0|\[::\]|localhost|127\.0\.0\.1|10\.|192\.168\.|172\.(1[6-9]|2[0-9]|3[0-1])\.|100\.(6[4-9]|[7-9][0-9]|1[0-1][0-9]|12[0-7])\.)/;
                    try {
                        const urlObj = new URL(connectionRequestUrl);
                        if (privateIpRegex.test(urlObj.hostname) && !privateIpRegex.test(ipAddress)) {
                            urlObj.hostname = ipAddress;
                            connectionRequestUrl = urlObj.toString();
                        }
                    }
                    catch (e) {
                        if (connectionRequestUrl.includes('0.0.0.0')) {
                            connectionRequestUrl = connectionRequestUrl.replace('0.0.0.0', ipAddress);
                        }
                        else if (connectionRequestUrl.includes('[::]')) {
                            connectionRequestUrl = connectionRequestUrl.replace('[::]', ipAddress);
                        }
                    }
                }
            }
            await this.prisma.device.update({
                where: { id: device.id },
                data: {
                    parameters: updatedParams,
                    ...(connectionRequestUrl && { connectionRequestUrl }),
                },
            });
            const discoveredLeaves = discovered._leaves || [];
            const fetchedCount = Object.keys(updatedValues).length;
            await this.prisma.task.updateMany({
                where: { deviceId: device.id, type: 'GetParameterValues', status: 'IN_PROGRESS' },
                data: { status: 'COMPLETED', result: paramMap },
            });
            if (discoveredLeaves.length > 0) {
                await this.prisma.log.create({
                    data: {
                        action: 'DISCOVERY',
                        entity: 'DEVICE',
                        entityId: device.id,
                        detail: `Discovered ${fetchedCount}/${discoveredLeaves.length} parameters for ${device.serial}`,
                        deviceId: device.id,
                        tenantId: device.tenantId,
                    },
                });
            }
        }
        return this.buildEmptySoapEnvelope();
    }
    async handleSetParameterValuesResponse(data) {
        const response = data?.['cwmp:SetParameterValuesResponse'] || data?.SetParameterValuesResponse;
        const paramKey = response?.ParameterKey || '';
        const status = response?.Status ?? 0;
        if (paramKey) {
            await this.prisma.task.updateMany({
                where: { id: paramKey },
                data: { status: status === 0 ? 'COMPLETED' : 'FAILED' },
            });
        }
        return this.buildEmptySoapEnvelope();
    }
    async handleGetParameterNamesResponse(data) {
        const response = data?.['cwmp:GetParameterNamesResponse'] || data?.GetParameterNamesResponse;
        if (!response || !this.lastSerial)
            return this.buildEmptySoapEnvelope();
        const paramList = response?.ParameterList?.ParameterInfoStruct || [];
        const params = Array.isArray(paramList) ? paramList : [paramList];
        this.logger.log(`[GPN-RESP] lastSerial=${this.lastSerial} names=${params.map((p) => p.Name).join('|').slice(0, 400)}`);
        const device = await this.prisma.device.findUnique({
            where: { serial: this.lastSerial },
        });
        if (!device)
            return this.buildEmptySoapEnvelope();
        const currentParams = device.parameters || {};
        const objectsToExplore = [];
        const leafParams = [];
        for (const p of params) {
            const name = p.Name || '';
            const writable = p.Writable === true || p.Writable === 'true';
            if (!name)
                continue;
            if (name.endsWith('.')) {
                objectsToExplore.push(name);
            }
            else {
                leafParams.push(name);
            }
        }
        const allParams = device.parameters || {};
        const discovered = allParams.__discovered__ || {};
        discovered._objects = [...new Set([...(discovered._objects || []), ...objectsToExplore])];
        discovered._leaves = [...new Set([...(discovered._leaves || []), ...leafParams])];
        discovered._writable = { ...(discovered._writable || {}), ...Object.fromEntries(params.filter((p) => p.Writable).map((p) => [p.Name, true])) };
        if (leafParams.length > 0) {
            await this.prisma.device.update({
                where: { id: device.id },
                data: { parameters: { ...allParams, __discovered__: discovered } },
            });
            const GPV_CHUNK_SIZE = 10;
            for (let i = 0; i < leafParams.length; i += GPV_CHUNK_SIZE) {
                const chunk = leafParams.slice(i, i + GPV_CHUNK_SIZE);
                const existingPending = await this.prisma.task.count({
                    where: { deviceId: device.id, type: 'GetParameterValues', status: 'PENDING' },
                });
                if (existingPending >= 50) {
                    this.logger.warn(`[DISCOVERY] Too many pending GPV tasks (${existingPending}) for ${device.serial}, skipping chunk`);
                    break;
                }
                await this.prisma.task.create({
                    data: {
                        deviceId: device.id,
                        type: 'GetParameterValues',
                        status: 'PENDING',
                        payload: { names: chunk },
                        tenantId: device.tenantId,
                    },
                });
            }
        }
        else {
            await this.prisma.device.update({
                where: { id: device.id },
                data: { parameters: { ...allParams, __discovered__: discovered } },
            });
        }
        if (objectsToExplore.length > 0) {
            for (const objPath of objectsToExplore) {
                await this.prisma.task.create({
                    data: {
                        deviceId: device.id,
                        type: 'GetParameterNames',
                        status: 'PENDING',
                        payload: { parameterPath: objPath, nextLevel: true },
                        tenantId: device.tenantId,
                    },
                });
            }
        }
        await this.prisma.task.updateMany({
            where: { deviceId: device.id, type: 'GetParameterNames', status: 'IN_PROGRESS' },
            data: { status: 'COMPLETED' },
        });
        return this.buildEmptySoapEnvelope();
    }
    async handleDownloadResponse(data) {
        return this.buildEmptySoapEnvelope();
    }
    async handleUploadResponse(data) {
        return this.buildEmptySoapEnvelope();
    }
    async handleRebootResponse(data) {
        return this.buildEmptySoapEnvelope();
    }
    async handleFactoryResetResponse(data) {
        return this.buildEmptySoapEnvelope();
    }
    async handleGetParameterValues(deviceId, paramNames) {
        const device = await this.prisma.device.findUnique({ where: { id: deviceId } });
        if (!device)
            throw new Error('Device not found');
        const params = device.parameters || {};
        const result = paramNames.map((name) => ({
            Name: name,
            Value: params[name] || '',
        }));
        return this.buildSoapResponse('GetParameterValuesResponse', {
            ParameterList: { ParameterValueStruct: result },
        });
    }
    async handleSetParameterValues(deviceId, params) {
        const device = await this.prisma.device.findUnique({ where: { id: deviceId } });
        if (!device)
            throw new Error('Device not found');
        const currentParams = device.parameters || {};
        for (const p of params) {
            currentParams[p.name] = p.value;
        }
        await this.prisma.device.update({
            where: { id: deviceId },
            data: { parameters: currentParams },
        });
        return this.buildSoapResponse('SetParameterValuesResponse', { Status: 0 });
    }
    async handleReboot(deviceId) {
        const device = await this.prisma.device.findUnique({ where: { id: deviceId } });
        if (!device)
            throw new Error('Device not found');
        await this.prisma.task.create({
            data: {
                deviceId,
                type: 'Reboot',
                status: 'PENDING',
                payload: { command: 'Reboot' },
                tenantId: device.tenantId,
            },
        });
        this.ws.broadcast('device:command', { deviceId, command: 'Reboot', timestamp: new Date() });
        return this.buildSoapResponse('RebootResponse', {});
    }
    async handleFactoryReset(deviceId) {
        const device = await this.prisma.device.findUnique({ where: { id: deviceId } });
        if (!device)
            throw new Error('Device not found');
        await this.prisma.task.create({
            data: {
                deviceId,
                type: 'FactoryReset',
                status: 'PENDING',
                payload: { command: 'FactoryReset' },
                tenantId: device.tenantId,
            },
        });
        return this.buildSoapResponse('FactoryResetResponse', {});
    }
    async handleDownload(deviceId, url, fileType = '1 Firmware Upgrade Image') {
        const device = await this.prisma.device.findUnique({ where: { id: deviceId } });
        if (!device)
            throw new Error('Device not found');
        const task = await this.prisma.task.create({
            data: {
                deviceId,
                type: 'Download',
                status: 'PENDING',
                payload: { url, fileType },
                tenantId: device.tenantId,
            },
        });
        return this.buildSoapResponse('DownloadResponse', {
            Status: 0,
            StartTime: new Date().toISOString(),
            CompleteTime: new Date(Date.now() + 600000).toISOString(),
            CommandKey: task.id,
        });
    }
    async handleFirmwareUpdate(deviceId) {
        const device = await this.prisma.device.findUnique({
            where: { id: deviceId },
            include: { firmware: true, model: { include: { firmwares: { where: { status: 'LATEST' }, take: 1 } } } },
        });
        if (!device)
            throw new Error('Device not found');
        if (device.firmware && device.firmware.status === 'LATEST') {
            return { message: 'Device already has latest firmware', firmware: device.firmware.version };
        }
        let latestFirmware = device.model?.firmwares?.[0] || device.firmware;
        const params = device.parameters || {};
        const oui = device.manufacturer
            || params['DeviceID.OUI']
            || '';
        const productClass = device.modelName
            || params['DeviceID.ProductClass']
            || '';
        if (!latestFirmware && oui && productClass) {
            const modelByOuiPc = await this.prisma.deviceModel.findFirst({
                where: { manufacturer: { contains: oui }, name: productClass, tenantId: device.tenantId },
                include: { firmwares: { where: { status: 'LATEST' }, take: 1 } },
            });
            if (modelByOuiPc?.firmwares?.[0]) {
                latestFirmware = modelByOuiPc.firmwares[0];
                if (!device.modelId) {
                    await this.prisma.device.update({
                        where: { id: deviceId },
                        data: { modelId: modelByOuiPc.id },
                    });
                }
            }
        }
        if (!latestFirmware) {
            throw new Error(`No firmware available for device ${device.serial} (OUI=${oui || '?'}, ProductClass=${productClass || '?'})`);
        }
        const downloadUrl = latestFirmware.filePath || `http://acs.local:7567/${latestFirmware.fileName}`;
        return this.handleDownload(deviceId, downloadUrl, '1 Firmware Upgrade Image');
    }
    async handleSetWiFiConfig(deviceId, params) {
        const device = await this.prisma.device.findUnique({ where: { id: deviceId } });
        if (!device)
            throw new Error('Device not found');
        const instance = Math.min(Math.max(parseInt(String(params.instance ?? 1), 10) || 1, 1), 8);
        const currentParams = device.parameters || {};
        const hasWLAN = Object.keys(currentParams).some((k) => k.startsWith('InternetGatewayDevice.LANDevice.1.WLANConfiguration.'));
        const hasTR181 = Object.keys(currentParams).some((k) => k.startsWith('Device.WiFi.'));
        const hasZTE = Object.keys(currentParams).some((k) => k.startsWith('InternetGatewayDevice.LANDevice.1.WIFI.'));
        const checkInstance = (prefix) => Object.keys(currentParams).some((k) => k.startsWith(prefix.replace('{i}', String(instance))));
        const instHasWLAN = checkInstance('InternetGatewayDevice.LANDevice.1.WLANConfiguration.{i}.');
        const instHasZTE = checkInstance('InternetGatewayDevice.LANDevice.1.WIFI.SSID.{i}.');
        const instHasTR181 = checkInstance('Device.WiFi.SSID.{i}.');
        let wifiParams;
        if (instHasZTE) {
            wifiParams = [
                { name: `InternetGatewayDevice.LANDevice.1.WIFI.SSID.${instance}.SSID`, value: params.ssid },
                { name: `InternetGatewayDevice.LANDevice.1.WIFI.SSID.${instance}.Enable`, value: '1' },
                { name: `InternetGatewayDevice.LANDevice.1.WIFI.AccessPoint.${instance}.Security.KeyPassphrase`, value: params.password },
                { name: `InternetGatewayDevice.LANDevice.1.WIFI.AccessPoint.${instance}.SSID`, value: params.ssid },
                { name: `InternetGatewayDevice.LANDevice.1.WIFI.AccessPoint.${instance}.Enable`, value: '1' },
            ];
        }
        else if (instHasTR181) {
            wifiParams = [
                { name: `Device.WiFi.SSID.${instance}.SSID`, value: params.ssid },
                { name: `Device.WiFi.SSID.${instance}.Enable`, value: '1' },
                { name: `Device.WiFi.AccessPoint.${instance}.Security.KeyPassphrase`, value: params.password },
                { name: `Device.WiFi.AccessPoint.${instance}.SSID`, value: params.ssid },
                { name: `Device.WiFi.AccessPoint.${instance}.Enable`, value: '1' },
            ];
        }
        else if (instHasWLAN) {
            wifiParams = [
                { name: `InternetGatewayDevice.LANDevice.1.WLANConfiguration.${instance}.SSID`, value: params.ssid },
                { name: `InternetGatewayDevice.LANDevice.1.WLANConfiguration.${instance}.KeyPassphrase`, value: params.password },
                { name: `InternetGatewayDevice.LANDevice.1.WLANConfiguration.${instance}.Enable`, value: '1' },
            ];
        }
        else {
            const useZTE = hasZTE;
            const useTR181 = hasTR181 && !hasZTE && !hasWLAN;
            if (useZTE) {
                wifiParams = [
                    { name: `InternetGatewayDevice.LANDevice.1.WIFI.SSID.${instance}.SSID`, value: params.ssid },
                    { name: `InternetGatewayDevice.LANDevice.1.WIFI.SSID.${instance}.Enable`, value: '1' },
                    { name: `InternetGatewayDevice.LANDevice.1.WIFI.AccessPoint.${instance}.Security.KeyPassphrase`, value: params.password },
                    { name: `InternetGatewayDevice.LANDevice.1.WIFI.AccessPoint.${instance}.SSID`, value: params.ssid },
                    { name: `InternetGatewayDevice.LANDevice.1.WIFI.AccessPoint.${instance}.Enable`, value: '1' },
                ];
            }
            else if (useTR181) {
                wifiParams = [
                    { name: `Device.WiFi.SSID.${instance}.SSID`, value: params.ssid },
                    { name: `Device.WiFi.AccessPoint.${instance}.Security.KeyPassphrase`, value: params.password },
                ];
            }
            else {
                wifiParams = [
                    { name: `InternetGatewayDevice.LANDevice.1.WLANConfiguration.${instance}.SSID`, value: params.ssid },
                    { name: `InternetGatewayDevice.LANDevice.1.WLANConfiguration.${instance}.KeyPassphrase`, value: params.password },
                ];
            }
        }
        const task = await this.prisma.task.create({
            data: {
                deviceId,
                type: 'SetParameterValues',
                status: 'PENDING',
                payload: { params: wifiParams },
                tenantId: device.tenantId,
                createdAt: new Date(Date.now() - 3 * 60 * 60 * 1000),
            },
        });
        for (const p of wifiParams) {
            currentParams[p.name] = p.value;
        }
        await this.prisma.device.update({
            where: { id: deviceId },
            data: { parameters: currentParams },
        });
        this.ws.broadcast('device:command', { deviceId, command: 'SetWiFi', timestamp: new Date() });
        await this.prisma.log.create({
            data: {
                action: 'WIFI_CONFIG',
                entity: 'DEVICE',
                entityId: deviceId,
                detail: `WiFi config queued for ${device.serial}`,
                tenantId: device.tenantId,
            },
        });
        return { task, message: 'WiFi configuration queued. Will be applied on next CPE connection.' };
    }
    async handleSetWiFiEnable(deviceId, params) {
        const device = await this.prisma.device.findUnique({ where: { id: deviceId } });
        if (!device)
            throw new Error('Device not found');
        const instance = Math.min(Math.max(parseInt(String(params.instance ?? 1), 10) || 1, 1), 8);
        const value = params.enabled ? '1' : '0';
        const currentParams = device.parameters || {};
        const checkInstance = (prefix) => Object.keys(currentParams).some((k) => k.startsWith(prefix.replace('{i}', String(instance))));
        const instHasWLAN = checkInstance('InternetGatewayDevice.LANDevice.1.WLANConfiguration.{i}.');
        const instHasZTE = checkInstance('InternetGatewayDevice.LANDevice.1.WIFI.SSID.{i}.');
        const instHasTR181 = checkInstance('Device.WiFi.SSID.{i}.');
        let wifiParams;
        if (instHasZTE) {
            wifiParams = [
                { name: `InternetGatewayDevice.LANDevice.1.WIFI.SSID.${instance}.Enable`, value },
                { name: `InternetGatewayDevice.LANDevice.1.WIFI.AccessPoint.${instance}.Enable`, value },
            ];
        }
        else if (instHasTR181) {
            wifiParams = [
                { name: `Device.WiFi.SSID.${instance}.Enable`, value },
                { name: `Device.WiFi.AccessPoint.${instance}.Enable`, value },
            ];
        }
        else if (instHasWLAN) {
            wifiParams = [
                { name: `InternetGatewayDevice.LANDevice.1.WLANConfiguration.${instance}.Enable`, value },
            ];
        }
        else {
            wifiParams = [
                { name: `InternetGatewayDevice.LANDevice.1.WLANConfiguration.${instance}.Enable`, value },
            ];
        }
        const task = await this.prisma.task.create({
            data: {
                deviceId,
                type: 'SetParameterValues',
                status: 'PENDING',
                payload: { params: wifiParams },
                tenantId: device.tenantId,
                createdAt: new Date(Date.now() - 3 * 60 * 60 * 1000),
            },
        });
        for (const p of wifiParams) {
            currentParams[p.name] = p.value;
        }
        await this.prisma.device.update({
            where: { id: deviceId },
            data: { parameters: currentParams },
        });
        this.ws.broadcast('device:command', { deviceId, command: 'SetWiFi', timestamp: new Date() });
        await this.prisma.log.create({
            data: {
                action: 'WIFI_ENABLE',
                entity: 'DEVICE',
                entityId: deviceId,
                detail: `WiFi ${params.enabled ? 'enabled' : 'disabled'} for ${device.serial}`,
                tenantId: device.tenantId,
            },
        });
        return { task, message: `WiFi ${params.enabled ? 'enabled' : 'disabled'} queued.` };
    }
    async handleReadWiFiConfig(deviceId) {
        const device = await this.prisma.device.findUnique({ where: { id: deviceId } });
        if (!device)
            throw new Error('Device not found');
        const model = device.modelId
            ? await this.prisma.deviceModel.findUnique({ where: { id: device.modelId } })
            : null;
        const unsupported = new Set(model?.unsupportedParameters || []);
        const filterUnsupported = (paths) => paths.filter((p) => !unsupported.has(p));
        const pendingTaskCount = await this.prisma.task.count({
            where: { deviceId, status: { in: ['PENDING', 'IN_PROGRESS'] } },
        });
        if (pendingTaskCount >= 20) {
            this.logger.warn(`[WIFI] Rate limit hit for ${device.serial} — ${pendingTaskCount} tasks already pending`);
            return {
                tasks: [],
                instances: 0,
                message: `Device already has ${pendingTaskCount} pending tasks. Try again later.`,
                source: 'rate_limited',
            };
        }
        const params = device.parameters || {};
        const discovered = params.__discovered__ || {};
        const leaves = discovered._leaves || [];
        const discoveredInstances = new Set();
        const instanceRe = /WLANConfiguration\.(\d+)\.|\.WIFI\.SSID\.(\d+)\.|\.WiFi\.SSID\.(\d+)\./;
        for (const leaf of leaves) {
            const m = leaf.match(instanceRe);
            if (m) {
                const inst = parseInt(m[1] || m[2] || m[3], 10);
                if (inst > 0)
                    discoveredInstances.add(inst);
            }
        }
        const cachedInstanceRe = /WLANConfiguration\.(\d+)\.|\.WIFI\.SSID\.(\d+)\.|\.WiFi\.SSID\.(\d+)\./;
        for (const key of Object.keys(params)) {
            const m = key.match(cachedInstanceRe);
            if (m) {
                const inst = parseInt(m[1] || m[2] || m[3], 10);
                if (inst > 0)
                    discoveredInstances.add(inst);
            }
        }
        let instances;
        if (discoveredInstances.size > 0) {
            instances = Array.from(discoveredInstances).sort((a, b) => a - b);
        }
        else {
            instances = Array.from({ length: 8 }, (_, i) => i + 1);
        }
        const allKnownKeys = [
            ...Object.keys(params),
            ...(leaves || []),
            ...Object.keys(discovered._values || {}),
        ];
        const hasWLAN = allKnownKeys.some((k) => k.startsWith('InternetGatewayDevice.LANDevice.1.WLANConfiguration.'));
        const hasTR181 = allKnownKeys.some((k) => k.startsWith('Device.WiFi.'));
        const hasZTE = allKnownKeys.some((k) => k.startsWith('InternetGatewayDevice.LANDevice.1.WIFI.'));
        const isTPLink = (device.manufacturer || '').toLowerCase().includes('tp-link')
            || allKnownKeys.some((k) => k.includes('X_TP_'));
        const tr181SSIDCount = leaves.filter((l) => l.startsWith('Device.WiFi.SSID.') && l.endsWith('.SSID')).length;
        const tr098SSIDCount = leaves.filter((l) => l.startsWith('InternetGatewayDevice.LANDevice.1.WLANConfiguration.') && l.endsWith('.SSID')).length;
        const prefersTR181 = isTPLink
            || (hasTR181 && tr181SSIDCount > tr098SSIDCount)
            || (hasTR181 && !hasWLAN);
        const noneDetected = !hasWLAN && !hasZTE && !hasTR181 && instances.length > 0;
        const useTR181 = prefersTR181 || noneDetected;
        const useWLAN = hasWLAN && !useTR181;
        const useZTE = !useWLAN && !useTR181 && hasZTE;
        const essentialPathsByInstance = {};
        const vendorPathsByInstance = {};
        const hostPathsByInstance = {};
        const isZTE = (device.manufacturer || '').toLowerCase().includes('zte')
            || allKnownKeys.some((k) => k.includes('X_ZTE-COM_'));
        for (const i of instances) {
            essentialPathsByInstance[i] = [];
            vendorPathsByInstance[i] = [];
            hostPathsByInstance[i] = [];
            if (useZTE) {
                essentialPathsByInstance[i].push(`InternetGatewayDevice.LANDevice.1.WIFI.SSID.${i}.SSID`, `InternetGatewayDevice.LANDevice.1.WIFI.SSID.${i}.Enable`, `InternetGatewayDevice.LANDevice.1.WIFI.SSID.${i}.Status`, `InternetGatewayDevice.LANDevice.1.WIFI.AccessPoint.${i}.SSID`, `InternetGatewayDevice.LANDevice.1.WIFI.AccessPoint.${i}.Enable`, `InternetGatewayDevice.LANDevice.1.WIFI.AccessPoint.${i}.Security.KeyPassphrase`);
                vendorPathsByInstance[i].push(`InternetGatewayDevice.LANDevice.1.WIFI.SSID.${i}.X_ZTE-COM_OperatingFrequencyBand`);
            }
            if (useWLAN) {
                essentialPathsByInstance[i].push(`InternetGatewayDevice.LANDevice.1.WLANConfiguration.${i}.SSID`, `InternetGatewayDevice.LANDevice.1.WLANConfiguration.${i}.KeyPassphrase`, `InternetGatewayDevice.LANDevice.1.WLANConfiguration.${i}.Enable`, `InternetGatewayDevice.LANDevice.1.WLANConfiguration.${i}.Channel`, `InternetGatewayDevice.LANDevice.1.WLANConfiguration.${i}.Status`, `InternetGatewayDevice.LANDevice.1.WLANConfiguration.${i}.Standard`, `InternetGatewayDevice.LANDevice.1.WLANConfiguration.${i}.TotalAssociations`);
                if (isZTE) {
                    vendorPathsByInstance[i].push(`InternetGatewayDevice.LANDevice.1.WLANConfiguration.${i}.X_ZTE-COM_OperatingFrequencyBand`, `InternetGatewayDevice.LANDevice.1.WLANConfiguration.${i}.X_ZTE-COM_WLAN_SupportedFrequencyBands`);
                }
                const knownTotal = parseInt(params[`InternetGatewayDevice.LANDevice.1.WLANConfiguration.${i}.TotalAssociations`] || '', 10);
                const maxHosts = Number.isFinite(knownTotal) && knownTotal > 0 ? knownTotal : 4;
                for (let c = 1; c <= maxHosts; c++) {
                    hostPathsByInstance[i].push(`InternetGatewayDevice.LANDevice.1.WLANConfiguration.${i}.AssociatedDevice.${c}.AssociatedDeviceMACAddress`, `InternetGatewayDevice.LANDevice.1.WLANConfiguration.${i}.AssociatedDevice.${c}.AssociatedDeviceIPAddress`, ...(isZTE ? [`InternetGatewayDevice.LANDevice.1.WLANConfiguration.${i}.AssociatedDevice.${c}.X_ZTE-COM_AssociatedDeviceName`] : []));
                }
            }
            if (useTR181 && i <= 4) {
                essentialPathsByInstance[i].push(`Device.WiFi.SSID.${i}.SSID`, `Device.WiFi.SSID.${i}.Enable`, `Device.WiFi.AccessPoint.${i}.Security.KeyPassphrase`, `Device.WiFi.AccessPoint.${i}.AssociatedDeviceNumberOfEntries`);
            }
            else if (useTR181 && i > 4) {
                this.logger.debug(`[WIFI] Skipping TR-181 instance ${i} — only reading 1-4`);
            }
        }
        if (useTR181 && instances.length > 4) {
            this.logger.log(`[WIFI] Limiting TR-181 instances from ${instances.length} to 4 for device ${device.serial}`);
        }
        const knownInstances = new Set();
        for (const i of instances) {
            const ssid = params[`InternetGatewayDevice.LANDevice.1.WLANConfiguration.${i}.SSID`]
                || params[`Device.WiFi.SSID.${i}.SSID`]
                || params[`InternetGatewayDevice.LANDevice.1.WIFI.SSID.${i}.SSID`]
                || params[`InternetGatewayDevice.LANDevice.1.WIFI.AccessPoint.${i}.SSID`];
            if (ssid !== undefined)
                knownInstances.add(i);
        }
        const existingParams = {};
        const allPaths = [
            ...Object.values(essentialPathsByInstance).flat(),
            ...Object.values(vendorPathsByInstance).flat(),
            ...Object.values(hostPathsByInstance).flat(),
        ];
        for (const path of allPaths) {
            const v = params[path];
            if (v === undefined || v === '')
                continue;
            existingParams[path] = v;
        }
        let cacheComplete = knownInstances.size > 0;
        if (cacheComplete) {
            for (const idx of knownInstances) {
                const ssid = existingParams[`InternetGatewayDevice.LANDevice.1.WLANConfiguration.${idx}.SSID`]
                    || existingParams[`Device.WiFi.SSID.${idx}.SSID`]
                    || existingParams[`InternetGatewayDevice.LANDevice.1.WIFI.SSID.${idx}.SSID`]
                    || existingParams[`InternetGatewayDevice.LANDevice.1.WIFI.AccessPoint.${idx}.SSID`];
                const ch = existingParams[`InternetGatewayDevice.LANDevice.1.WLANConfiguration.${idx}.Channel`]
                    || existingParams[`InternetGatewayDevice.LANDevice.1.WIFI.SSID.${idx}.Channel`];
                const en = existingParams[`InternetGatewayDevice.LANDevice.1.WLANConfiguration.${idx}.Enable`]
                    || existingParams[`Device.WiFi.SSID.${idx}.Enable`]
                    || existingParams[`InternetGatewayDevice.LANDevice.1.WIFI.SSID.${idx}.Enable`];
                const assoc = existingParams[`InternetGatewayDevice.LANDevice.1.WLANConfiguration.${idx}.TotalAssociations`];
                const missing = !ssid || ch === undefined || en === undefined
                    || (en === '1' && assoc === undefined);
                if (missing) {
                    cacheComplete = false;
                    break;
                }
            }
        }
        if (cacheComplete) {
            return { params: existingParams, source: 'cache' };
        }
        const MAX_PARAMS_PER_TASK = 25;
        const createdTasks = [];
        let taskCount = 0;
        const chunkArray = (arr, size) => {
            const result = [];
            for (let i = 0; i < arr.length; i += size)
                result.push(arr.slice(i, i + size));
            return result;
        };
        for (const instance of instances) {
            const essential = filterUnsupported(essentialPathsByInstance[instance] || []);
            const vendor = filterUnsupported(vendorPathsByInstance[instance] || []);
            const hosts = filterUnsupported(hostPathsByInstance[instance] || []);
            const hasAllEssential = essential.every((p) => params[p] !== undefined && params[p] !== '');
            if (essential.length > 0 && !hasAllEssential && taskCount < 10) {
                for (const chunk of chunkArray(essential, MAX_PARAMS_PER_TASK)) {
                    const task = await this.prisma.task.create({
                        data: {
                            deviceId,
                            type: 'GetParameterValues',
                            status: 'PENDING',
                            payload: { names: chunk },
                            tenantId: device.tenantId,
                        },
                    });
                    createdTasks.push(task);
                    taskCount++;
                }
            }
            if (vendor.length > 0 && taskCount < 15) {
                const vendorParamsAlreadyCached = vendor.every((p) => params[p] !== undefined && params[p] !== '');
                if (!vendorParamsAlreadyCached) {
                    for (const chunk of chunkArray(vendor, MAX_PARAMS_PER_TASK)) {
                        const task = await this.prisma.task.create({
                            data: {
                                deviceId,
                                type: 'GetParameterValues',
                                status: 'PENDING',
                                payload: { names: chunk },
                                tenantId: device.tenantId,
                            },
                        });
                        createdTasks.push(task);
                        taskCount++;
                    }
                }
            }
            if (hosts.length > 0 && taskCount < 20) {
                for (const chunk of chunkArray(hosts, MAX_PARAMS_PER_TASK)) {
                    const hostTask = await this.prisma.task.create({
                        data: {
                            deviceId,
                            type: 'GetParameterValues',
                            status: 'PENDING',
                            payload: { names: chunk },
                            tenantId: device.tenantId,
                        },
                    });
                    createdTasks.push(hostTask);
                    taskCount++;
                }
            }
        }
        if (taskCount === 0 && !hasWLAN && !hasZTE && !hasTR181) {
            const discTask = await this.prisma.task.create({
                data: {
                    deviceId,
                    type: 'GetParameterNames',
                    status: 'PENDING',
                    payload: { parameterPath: 'Device.WiFi.', nextLevel: true },
                    tenantId: device.tenantId,
                },
            });
            createdTasks.push(discTask);
            taskCount++;
            this.logger.log(`[WIFI_READ] Queued targeted discovery Device.WiFi. for ${device.serial}`);
        }
        await this.prisma.log.create({
            data: {
                action: 'WIFI_READ',
                entity: 'DEVICE',
                entityId: deviceId,
                detail: `Reading WiFi config from ${device.serial} (${createdTasks.length} tasks queued, ${instances.length} instances)`,
                tenantId: device.tenantId,
            },
        });
        return {
            tasks: createdTasks,
            instances: instances.length,
            message: `Fetching WiFi parameters from CPE... (${createdTasks.length} tasks queued)`,
            source: 'pending',
        };
    }
    async handleGetConnectedDevices(deviceId) {
        const device = await this.prisma.device.findUnique({ where: { id: deviceId } });
        if (!device)
            throw new Error('Device not found');
        const params = device.parameters || {};
        const str = (v) => {
            if (typeof v === 'string')
                return v;
            if (v && typeof v === 'object') {
                return v.$ || v._value || v.value || String(v);
            }
            return '';
        };
        const connectedDevices = [];
        const hasWLAN = Object.keys(params).some((k) => k.startsWith('InternetGatewayDevice.LANDevice.1.WLANConfiguration.'));
        const hasTR181_AP = Object.keys(params).some((k) => k.startsWith('Device.WiFi.AccessPoint.'));
        for (let wlan = 1; wlan <= 8; wlan++) {
            let devIndex = 1;
            while (true) {
                const basePath = `InternetGatewayDevice.LANDevice.1.WLANConfiguration.${wlan}.AssociatedDevice.${devIndex}`;
                const mac = str(params[`${basePath}.AssociatedDeviceMACAddress`]);
                if (!mac)
                    break;
                connectedDevices.push({
                    interface: `WLAN.${wlan}`,
                    mac,
                    name: str(params[`${basePath}.X_ZTE-COM_AssociatedDeviceName`]),
                    ip: str(params[`${basePath}.AssociatedDeviceIPAddress`]),
                    rssi: parseInt(str(params[`${basePath}.AssociatedDeviceRssi`])) || 0,
                    snr: parseInt(str(params[`${basePath}.X_ZTE-COM_WLAN_SNR`])) || 0,
                    noise: parseInt(str(params[`${basePath}.X_ZTE-COM_WLAN_Noise`])) || 0,
                    bandwidth: str(params[`${basePath}.AssociatedDeviceBandWidth`]),
                    txRate: parseInt(str(params[`${basePath}.X_ZTE-COM_TXRate`])) || 0,
                    rxRate: parseInt(str(params[`${basePath}.X_ZTE-COM_RXRate`])) || 0,
                    bytesReceived: parseInt(str(params[`${basePath}.X_ZTE-COM_WLAN_BytesReceived`])) || 0,
                    bytesSend: parseInt(str(params[`${basePath}.X_ZTE-COM_WLAN_BytesSend`])) || 0,
                    stayTime: str(params[`${basePath}.X_ZTE-COM_StayTime`]),
                    radio: str(params[`${basePath}.X_ZTE-COM_WLAN_Radio`]),
                    clientMode: str(params[`${basePath}.X_ZTE-COM_WLAN_ClientMode`]),
                    clientChannelWidth: str(params[`${basePath}.X_ZTE-COM_WLAN_ClientChannelWidth`]),
                    signalStrength: parseInt(str(params[`${basePath}.X_ZTE-COM_SignalStrength`])) || 0,
                });
                devIndex++;
            }
        }
        for (let ap = 1; ap <= 16; ap++) {
            let devIndex = 1;
            while (true) {
                const basePath = `Device.WiFi.AccessPoint.${ap}.AssociatedDevice.${devIndex}`;
                const mac = str(params[`${basePath}.AssociatedDeviceMACAddress`]);
                if (!mac)
                    break;
                connectedDevices.push({
                    interface: `AP.${ap}`,
                    mac,
                    name: str(params[`${basePath}.X_TP_HostName`]) || str(params[`${basePath}.X_ZTE-COM_AssociatedDeviceName`]),
                    ip: str(params[`${basePath}.AssociatedDeviceIPAddress`]),
                    rssi: parseInt(str(params[`${basePath}.AssociatedDeviceRSSI`]) || str(params[`${basePath}.AssociatedDeviceRssi`])) || 0,
                    snr: 0,
                    noise: 0,
                    bandwidth: str(params[`${basePath}.AssociatedDeviceBandwidth`] || params[`${basePath}.AssociatedDeviceBandWidth`]),
                    txRate: parseInt(str(params[`${basePath}.X_TP_TXRate`] || params[`${basePath}.X_TP_TxRate`] || params[`${basePath}.X_ZTE-COM_TXRate`])) || 0,
                    rxRate: parseInt(str(params[`${basePath}.X_TP_RXRate`] || params[`${basePath}.X_TP_RxRate`] || params[`${basePath}.X_ZTE-COM_RXRate`])) || 0,
                    bytesReceived: 0,
                    bytesSend: 0,
                    stayTime: str(params[`${basePath}.AssociatedDeviceLastDataTransmitTime`] || params[`${basePath}.X_ZTE-COM_StayTime`]),
                    radio: str(params[`${basePath}.AssociatedDeviceOperatingFrequencyBand`]),
                    clientMode: '',
                    clientChannelWidth: '',
                    signalStrength: 0,
                });
                devIndex++;
            }
        }
        return connectedDevices;
    }
    async handleDiscover(deviceId) {
        const device = await this.prisma.device.findUnique({ where: { id: deviceId } });
        if (!device)
            throw new Error('Device not found');
        const currentParams = device.parameters || {};
        await this.prisma.device.update({
            where: { id: deviceId },
            data: {
                parameters: { ...currentParams, __discovered__: { _objects: [], _leaves: [], _values: {}, _writable: {} } },
            },
        });
        const task = await this.prisma.task.create({
            data: {
                deviceId,
                type: 'GetParameterNames',
                status: 'PENDING',
                payload: { parameterPath: '', nextLevel: true },
                tenantId: device.tenantId,
            },
        });
        await this.prisma.log.create({
            data: {
                action: 'DISCOVERY',
                entity: 'DEVICE',
                entityId: deviceId,
                detail: `Full parameter discovery started for ${device.serial}`,
                deviceId,
                tenantId: device.tenantId,
            },
        });
        return { task, message: 'Full parameter discovery queued. Will process on next CPE connection.' };
    }
    async handleFetchAllParams(deviceId, paramNames = ['Device.', 'InternetGatewayDevice.']) {
        const device = await this.prisma.device.findUnique({ where: { id: deviceId } });
        if (!device)
            throw new Error('Device not found');
        const task = await this.prisma.task.create({
            data: {
                deviceId,
                type: 'GetParameterValues',
                status: 'PENDING',
                payload: { names: paramNames },
                tenantId: device.tenantId,
            },
        });
        await this.prisma.log.create({
            data: {
                action: 'FETCH_PARAMS',
                entity: 'DEVICE',
                entityId: deviceId,
                detail: `Fetching all params (${paramNames.join(', ')}) for ${device.serial}`,
                deviceId,
                tenantId: device.tenantId,
            },
        });
        return { task, message: `Fetching ${paramNames.length} parameter trees from CPE...` };
    }
    async handleGetDiscoveryStatus(deviceId) {
        const device = await this.prisma.device.findUnique({ where: { id: deviceId } });
        if (!device)
            throw new Error('Device not found');
        const allParams = device.parameters || {};
        const discovered = allParams.__discovered__ || {};
        const objects = discovered._objects || [];
        const leaves = discovered._leaves || [];
        const values = discovered._values || {};
        const writable = discovered._writable || {};
        const fetchedCount = Object.keys(values).length;
        const totalParams = leaves.length;
        const pendingTasks = await this.prisma.task.count({
            where: { deviceId, type: { in: ['GetParameterNames', 'GetParameterValues'] }, status: { in: ['PENDING', 'IN_PROGRESS'] } },
        });
        const IGD_WLAN_PREFIX = 'InternetGatewayDevice.LANDevice.';
        const TR181_WIFI_PREFIX = 'Device.WiFi.';
        const wifiParams = Object.fromEntries(Object.entries(values).filter(([key]) => {
            if (key.startsWith(IGD_WLAN_PREFIX) && key.includes('.WLANConfiguration.'))
                return true;
            if (key.startsWith(TR181_WIFI_PREFIX))
                return true;
            return false;
        }));
        return {
            status: pendingTasks > 0 ? 'scanning' : (totalParams > 0 ? 'complete' : 'idle'),
            objects: objects.length,
            leaves: totalParams,
            fetched: fetchedCount,
            pendingTasks,
            progress: totalParams > 0 ? Math.round((fetchedCount / totalParams) * 100) : 0,
            parameters: values,
            writable,
            wifiParams,
        };
    }
    async handleUpload(deviceId, fileType) {
        return this.buildSoapResponse('UploadResponse', {
            Status: 0,
            StartTime: new Date().toISOString(),
            CompleteTime: new Date(Date.now() + 600000).toISOString(),
        });
    }
    async buildCwmpCommand(task, deviceId) {
        const wrap = (xml) => `<?xml version="1.0" encoding="UTF-8"?>\n${xml}`;
        switch (task.type) {
            case 'Reboot':
                return wrap(this.builder.build(this.buildSoapResponse('Reboot', { 'cwmp:CommandKey': task.id })));
            case 'FactoryReset':
                return wrap(this.builder.build(this.buildSoapResponse('FactoryReset', { 'cwmp:CommandKey': task.id })));
            case 'Download': {
                const payload = task.payload;
                return wrap(this.builder.build(this.buildSoapResponse('Download', {
                    'cwmp:CommandKey': task.id,
                    'cwmp:FileType': payload?.fileType || '1 Firmware Upgrade Image',
                    'cwmp:URL': payload?.url || '',
                    'cwmp:Username': '',
                    'cwmp:Password': '',
                    'cwmp:FileSize': 0,
                    'cwmp:TargetFileName': '',
                    'cwmp:DelaySeconds': 0,
                    'cwmp:SuccessURL': '',
                    'cwmp:FailureURL': '',
                })));
            }
            case 'GetParameterNames': {
                const payload = task.payload;
                const paramPath = payload?.parameterPath || '';
                const nextLevel = payload?.nextLevel ?? true;
                return wrap(this.builder.build(this.buildSoapResponse('GetParameterNames', {
                    'cwmp:ParameterPath': paramPath,
                    'cwmp:NextLevel': nextLevel,
                })));
            }
            case 'GetParameterValues': {
                const payload = task.payload;
                const names = payload?.names || ['Device.DeviceInfo.*'];
                const gpvXml = wrap(this.builder.build(this.buildSoapResponse('GetParameterValues', {
                    'cwmp:ParameterNames': {
                        '@_soap-enc:arrayType': `xsd:string[${names.length}]`,
                        string: names,
                    },
                })));
                this.logger.log(`[GPV-SEND] task=${task.id} count=${names.length} first=${names[0]} last=${names[names.length - 1]}`);
                return gpvXml;
            }
            case 'SetParameterValues':
            case 'Provision': {
                const payload = task.payload;
                let params = payload?.parameters
                    ? Object.entries(payload.parameters).map(([name, value]) => ({ name, value }))
                    : (payload?.params || []);
                if (params.length === 0)
                    return this.buildEmptySoapEnvelope();
                const hasTR181 = params.some((p) => p.name.startsWith('Device.'));
                const hasTR098 = params.some((p) => p.name.startsWith('InternetGatewayDevice.'));
                if (hasTR181 && hasTR098) {
                    const tr181Batch = params.filter((p) => p.name.startsWith('Device.'));
                    const tr098Batch = params.filter((p) => p.name.startsWith('InternetGatewayDevice.'));
                    const otherBatch = params.filter((p) => !p.name.startsWith('Device.') && !p.name.startsWith('InternetGatewayDevice.'));
                    const keepBatch = tr181Batch.length >= tr098Batch.length ? tr181Batch : tr098Batch;
                    const requeueBatch = tr181Batch.length >= tr098Batch.length ? tr098Batch : tr181Batch;
                    params = [...otherBatch, ...keepBatch];
                    if (requeueBatch.length > 0) {
                        const requeueParams = {};
                        for (const p of requeueBatch)
                            requeueParams[p.name] = p.value;
                        await this.prisma.task.create({
                            data: {
                                deviceId: task.deviceId,
                                type: task.type,
                                status: 'PENDING',
                                payload: { parameters: requeueParams },
                                tenantId: task.tenantId,
                                maxAttempts: task.maxAttempts || 3,
                            },
                        });
                        this.logger.log(`[SPV-NAMESPACE] Split ${requeueBatch.length} params into separate task for device ${task.deviceId}`);
                    }
                }
                const maxSpvBatch = 10;
                const batch = params.slice(0, maxSpvBatch);
                if (params.length > maxSpvBatch) {
                    this.logger.warn(`[SPV] Truncating SetParameterValues from ${params.length} to ${maxSpvBatch} params to avoid Fault 9814`);
                }
                return wrap(this.builder.build(this.buildSoapResponse('SetParameterValues', {
                    'cwmp:ParameterList': {
                        '@_soap-enc:arrayType': `cwmp:ParameterValueStruct[${batch.length}]`,
                        'cwmp:ParameterValueStruct': batch.map((p) => ({
                            'cwmp:Name': p.name,
                            'cwmp:Value': { '#text': p.value, '@_xsi:type': 'xsd:string' },
                        })),
                    },
                    'cwmp:ParameterKey': task.id,
                })));
            }
            default:
                return this.buildEmptySoapEnvelope();
        }
    }
    buildEmptySoapEnvelope() {
        return `<?xml version="1.0" encoding="UTF-8"?>
<soap:Envelope xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/" xmlns:cwmp="urn:dslforum-org:cwmp-1-0">
  <soap:Header>
    <cwmp:ID soap:mustUnderstand="1">0</cwmp:ID>
  </soap:Header>
  <soap:Body />
</soap:Envelope>`;
    }
    async getNextPendingTask(deviceId) {
        await this.prisma.task.updateMany({
            where: { deviceId, status: 'IN_PROGRESS' },
            data: { status: 'PENDING' },
        });
        const task = await this.prisma.task.findFirst({
            where: { deviceId, status: 'PENDING' },
            orderBy: [{ createdAt: 'asc' }],
        });
        if (!task)
            return null;
        await this.prisma.task.update({
            where: { id: task.id },
            data: { status: 'IN_PROGRESS' },
        });
        return task;
    }
    buildInformResponse(device, hasPendingTasks) {
        const responseObj = this.buildSoapResponse('InformResponse', {
            MaxEnvelopes: hasPendingTasks ? 2 : 1,
        });
        return `<?xml version="1.0" encoding="UTF-8"?>\n${this.builder.build(responseObj)}`;
    }
    async buildNextCommandResponse(device) {
        const task = await this.getNextPendingTask(device.id);
        if (!task) {
            return this.buildEmptySoapEnvelope();
        }
        await this.prisma.log.create({
            data: {
                action: 'CMD_SEND',
                entity: 'DEVICE',
                entityId: device.id,
                detail: `Sending ${task.type} (task=${task.id}) to ${device.serial}`,
                deviceId: device.id,
                tenantId: device.tenantId,
            },
        });
        const commandXml = await this.buildCwmpCommand(task, device.id);
        const commandBody = commandXml.replace(/^<\?xml[^>]*>\s*/, '');
        return `<?xml version="1.0" encoding="UTF-8"?>\n${commandBody}`;
    }
    async buildInformResponseWithTasks(device) {
        const pendingCount = await this.prisma.task.count({
            where: { deviceId: device.id, status: 'PENDING' },
        });
        return this.buildInformResponse(device, pendingCount > 0);
    }
    buildGetRPCMethodsResponse() {
        const responseObj = this.buildSoapResponse('GetRPCMethodsResponse', {
            MethodList: {
                string: [
                    'GetRPCMethods',
                    'SetParameterValues',
                    'GetParameterValues',
                    'GetParameterNames',
                    'SetParameterAttributes',
                    'GetParameterAttributes',
                    'AddObject',
                    'DeleteObject',
                    'Reboot',
                    'FactoryReset',
                    'Download',
                    'Upload',
                    'ScheduleInform',
                    'SetVouchers',
                    'GetAllQueuedTransfers',
                ],
            },
        });
        return `<?xml version="1.0" encoding="UTF-8"?>\n${this.builder.build(responseObj)}`;
    }
    buildFaultResponse(faultCode, faultString) {
        const responseObj = this.buildSoapResponse('Fault', {
            FaultCode: faultCode,
            FaultString: faultString,
        });
        return `<?xml version="1.0" encoding="UTF-8"?>\n${this.builder.build(responseObj)}`;
    }
    buildSoapResponse(action, body) {
        return {
            'soap:Envelope': {
                '@_xmlns:soap': 'http://schemas.xmlsoap.org/soap/envelope/',
                '@_xmlns:cwmp': 'urn:dslforum-org:cwmp-1-0',
                '@_xmlns:xsi': 'http://www.w3.org/2001/XMLSchema-instance',
                '@_xmlns:xsd': 'http://www.w3.org/2001/XMLSchema',
                '@_xmlns:soap-enc': 'http://schemas.xmlsoap.org/soap/encoding/',
                '@_soap:encodingStyle': 'http://schemas.xmlsoap.org/soap/encoding/',
                'soap:Header': {
                    'cwmp:ID': { '@_soap:mustUnderstand': '1', '#text': Date.now().toString() },
                },
                'soap:Body': {
                    [`cwmp:${action}`]: body,
                },
            },
        };
    }
    async markPathUnsupported(modelId, path) {
        if (!modelId)
            return;
        const model = await this.prisma.deviceModel.findUnique({ where: { id: modelId } });
        if (!model)
            return;
        const current = new Set(model.unsupportedParameters || []);
        if (current.has(path))
            return;
        current.add(path);
        await this.prisma.deviceModel.update({
            where: { id: modelId },
            data: { unsupportedParameters: Array.from(current) },
        });
        this.logger.warn(`[FAULT-9005] Path "${path}" marcado como unsupported permanentemente no modelo ${model.name}`);
    }
};
exports.CwmpService = CwmpService;
exports.CwmpService = CwmpService = CwmpService_1 = __decorate([
    (0, common_1.Injectable)(),
    __param(4, (0, common_1.Inject)((0, common_1.forwardRef)(() => devices_service_1.DevicesService))),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService,
        websocket_gateway_1.WebsocketGateway,
        scripts_service_1.ScriptsService,
        config_service_1.ConfigService,
        devices_service_1.DevicesService])
], CwmpService);
//# sourceMappingURL=cwmp.service.js.map
"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CliModule = void 0;
const common_1 = require("@nestjs/common");
const prisma_service_1 = require("../common/prisma.service");
const discovery_engine_module_1 = require("../discovery-engine/discovery-engine.module");
const tasks_module_1 = require("../tasks/tasks.module");
const scripts_module_1 = require("../scripts/scripts.module");
const device_inspect_command_1 = require("./commands/device-inspect.command");
const device_refresh_command_1 = require("./commands/device-refresh.command");
const tasks_pending_command_1 = require("./commands/tasks-pending.command");
const tasks_reset_stuck_command_1 = require("./commands/tasks-reset-stuck.command");
const model_unsupported_command_1 = require("./commands/model-unsupported.command");
const model_inspect_command_1 = require("./commands/model-inspect.command");
const provision_execute_command_1 = require("./commands/provision-execute.command");
let CliModule = class CliModule {
};
exports.CliModule = CliModule;
exports.CliModule = CliModule = __decorate([
    (0, common_1.Module)({
        imports: [discovery_engine_module_1.DiscoveryEngineModule, tasks_module_1.TasksModule, scripts_module_1.ScriptsModule],
        providers: [
            prisma_service_1.PrismaService,
            device_inspect_command_1.DeviceInspectCommand,
            device_refresh_command_1.DeviceRefreshCommand,
            tasks_pending_command_1.TasksPendingCommand,
            tasks_reset_stuck_command_1.TasksResetStuckCommand,
            model_unsupported_command_1.ModelUnsupportedCommand,
            model_inspect_command_1.ModelInspectCommand,
            provision_execute_command_1.ProvisionExecuteCommand,
        ],
    })
], CliModule);
//# sourceMappingURL=cli.module.js.map
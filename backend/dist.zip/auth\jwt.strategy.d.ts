import { Strategy } from 'passport-jwt';
import { PrismaService } from '../common/prisma.service';
declare const JwtStrategy_base: new (...args: any[]) => Strategy;
export declare class JwtStrategy extends JwtStrategy_base {
    private prisma;
    constructor(prisma: PrismaService);
    validate(payload: any): Promise<{
        id: string;
        email: string;
        name: string;
        role: import(".prisma/client").$Enums.Role;
        tenantId: string;
        tenant: {
            id: string;
            createdAt: Date;
            updatedAt: Date;
            name: string;
            slug: string;
            acsUsername: string;
            acsPassword: string;
            acsPublicUrl: string | null;
            connectionRequestEnabled: boolean;
            defaultWiFiConfig: import("@prisma/client/runtime/library").JsonValue | null;
            defaultScripts: import("@prisma/client/runtime/library").JsonValue | null;
        };
    }>;
}
export {};

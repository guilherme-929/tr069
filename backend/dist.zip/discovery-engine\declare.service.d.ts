import { PrismaService } from '../common/prisma.service';
export type DeclareResult = {
    status: 'cached' | 'refresh_scheduled' | 'discovery_scheduled' | 'unsupported';
    path: string;
    value?: string;
    taskId?: string;
};
export declare class DeclareService {
    private prisma;
    private readonly logger;
    constructor(prisma: PrismaService);
    declare(deviceId: string, path: string, opts?: {
        maxAgeMs?: number;
    }): Promise<DeclareResult>;
    recordDiscovery(deviceId: string, paths: string[]): Promise<void>;
    recordValues(deviceId: string, values: Record<string, string>): Promise<void>;
    markUnsupported(deviceId: string, paths: string[]): Promise<void>;
    private createTask;
    private parentPrefix;
    private matchesAny;
}

import { AuthService } from './auth.service';
export declare class AuthController {
    private authService;
    constructor(authService: AuthService);
    register(data: {
        email: string;
        password: string;
        name: string;
        tenantSlug: string;
        tenantName: string;
    }): Promise<{
        accessToken: string;
        refreshToken: string;
        user: {
            id: any;
            email: any;
            name: any;
            role: any;
        };
    }>;
    login(data: {
        email: string;
        password: string;
    }): Promise<{
        accessToken: string;
        refreshToken: string;
        user: {
            id: any;
            email: any;
            name: any;
            role: any;
        };
    }>;
    refresh(data: {
        refreshToken: string;
    }): Promise<{
        accessToken: string;
        refreshToken: string;
        user: {
            id: any;
            email: any;
            name: any;
            role: any;
        };
    }>;
    getProfile(userId: string): Promise<{
        id: string;
        tenant: {
            id: string;
            name: string;
            slug: string;
        };
        name: string;
        email: string;
        isActive: boolean;
        role: import(".prisma/client").$Enums.Role;
        avatar: string | null;
    } | null>;
}

"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var DeclareService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.DeclareService = void 0;
const common_1 = require("@nestjs/common");
const prisma_service_1 = require("../common/prisma.service");
let DeclareService = DeclareService_1 = class DeclareService {
    constructor(prisma) {
        this.prisma = prisma;
        this.logger = new common_1.Logger(DeclareService_1.name);
    }
    async declare(deviceId, path, opts = {}) {
        const maxAgeMs = opts.maxAgeMs ?? 3600_000;
        const device = await this.prisma.device.findUnique({ where: { id: deviceId } });
        if (!device)
            throw new Error(`Device ${deviceId} not found`);
        if (device.modelId) {
            const model = await this.prisma.deviceModel.findUnique({ where: { id: device.modelId } });
            const unsupported = model?.unsupportedParameters || [];
            if (this.matchesAny(path, unsupported)) {
                this.logger.debug(`[DECLARE] ${path} marcado como unsupported para modelo ${model?.name} — pulando`);
                return { status: 'unsupported', path };
            }
        }
        const discovered = device.discoveredPaths || [];
        const isWildcard = path.includes('*');
        if (!isWildcard && discovered.includes(path)) {
            const meta = device.parameterMeta || {};
            const fetchedAt = meta[path] ? new Date(meta[path]).getTime() : 0;
            const isFresh = Date.now() - fetchedAt < maxAgeMs;
            if (isFresh) {
                const params = device.parameters || {};
                return { status: 'cached', path, value: params[path] };
            }
            const task = await this.createTask(device.id, device.tenantId, 'GetParameterValues', {
                parameterPaths: [path],
            });
            return { status: 'refresh_scheduled', path, taskId: task.id };
        }
        const scopePrefix = this.parentPrefix(path);
        const task = await this.createTask(device.id, device.tenantId, 'GetParameterNames', {
            parameterPath: scopePrefix,
            nextLevel: false,
        });
        this.logger.log(`[DECLARE] ${path} desconhecido — disparando discovery em ${scopePrefix} (task ${task.id})`);
        return { status: 'discovery_scheduled', path, taskId: task.id };
    }
    async recordDiscovery(deviceId, paths) {
        const device = await this.prisma.device.findUnique({ where: { id: deviceId } });
        if (!device)
            return;
        const current = new Set(device.discoveredPaths || []);
        for (const p of paths)
            current.add(p);
        await this.prisma.device.update({
            where: { id: deviceId },
            data: { discoveredPaths: Array.from(current) },
        });
    }
    async recordValues(deviceId, values) {
        const device = await this.prisma.device.findUnique({ where: { id: deviceId } });
        if (!device)
            return;
        const currentParams = device.parameters || {};
        const currentMeta = device.parameterMeta || {};
        const now = new Date().toISOString();
        for (const [path, value] of Object.entries(values)) {
            currentParams[path] = value;
            currentMeta[path] = now;
        }
        await this.prisma.device.update({
            where: { id: deviceId },
            data: { parameters: currentParams, parameterMeta: currentMeta },
        });
    }
    async markUnsupported(deviceId, paths) {
        const device = await this.prisma.device.findUnique({ where: { id: deviceId } });
        if (!device?.modelId)
            return;
        const model = await this.prisma.deviceModel.findUnique({ where: { id: device.modelId } });
        if (!model)
            return;
        const current = new Set(model.unsupportedParameters || []);
        for (const p of paths)
            current.add(p);
        await this.prisma.deviceModel.update({
            where: { id: model.id },
            data: { unsupportedParameters: Array.from(current) },
        });
        this.logger.warn(`[DECLARE] Modelo ${model.name}: marcando ${paths.length} path(s) como unsupported (Fault 9005)`);
    }
    async createTask(deviceId, tenantId, type, payload) {
        return this.prisma.task.create({
            data: { deviceId, tenantId, type, status: 'PENDING', payload },
        });
    }
    parentPrefix(path) {
        const idx = path.indexOf('*');
        const trimmed = idx === -1 ? path : path.slice(0, idx);
        return trimmed.replace(/\.$/, '');
    }
    matchesAny(path, patterns) {
        return patterns.some((p) => path === p || path.startsWith(p.replace(/\*$/, '')));
    }
};
exports.DeclareService = DeclareService;
exports.DeclareService = DeclareService = DeclareService_1 = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService])
], DeclareService);
//# sourceMappingURL=declare.service.js.map
import { AcsService } from './acs.service';
import { CwmpService } from './cwmp.service';
export declare class AcsController {
    private acsService;
    private cwmpService;
    constructor(acsService: AcsService, cwmpService: CwmpService);
    handleCwmp(body: string, req: any, res: any): Promise<void>;
    getStats(tenantId: string): Promise<{
        online: number;
        offline: number;
        totalDevices: number;
        totalModels: number;
        totalFirmwares: number;
        provisionedToday: number;
        alerts: {
            id: string;
            type: import(".prisma/client").$Enums.AlertType;
            tenantId: string;
            createdAt: Date;
            updatedAt: Date;
            deviceId: string | null;
            message: string | null;
            severity: import(".prisma/client").$Enums.AlertSeverity;
            title: string;
            read: boolean;
            resolved: boolean;
        }[];
    }>;
    getProvisioningPerHour(tenantId: string): Promise<{
        hour: string;
        count: number;
    }[]>;
    getNetworkAvailability(tenantId: string): Promise<{
        hour: string;
        availability: number;
    }[]>;
    connectionRequest(id: string): Promise<{
        success: boolean;
        message: string;
        statusCode?: number;
        executedImmediately?: boolean;
        queued?: boolean;
    }>;
    reboot(id: string): Promise<any>;
    factoryReset(id: string): Promise<any>;
    updateFirmware(id: string): Promise<any>;
    download(id: string, data: {
        url: string;
        fileType?: string;
    }): Promise<any>;
    getParameters(id: string, body: {
        names: string[];
    }): Promise<any>;
    setParameters(id: string, body: {
        params: {
            name: string;
            value: string;
        }[];
    }): Promise<any>;
    setWiFi(id: string, body: {
        ssid: string;
        password: string;
        instance?: number;
    }): Promise<any>;
    enableWiFi(id: string, body: {
        enabled: boolean;
        instance: number;
    }): Promise<any>;
    readWiFi(id: string): Promise<any>;
    fetchAll(id: string, body: {
        names?: string[];
        connectionRequest?: boolean;
    }): Promise<any>;
    discover(id: string): Promise<any>;
    getConnectedDevices(id: string): Promise<any>;
    discoverStatus(id: string): Promise<any>;
}

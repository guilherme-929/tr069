export declare class AlertsModule {
}

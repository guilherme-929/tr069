import { CommandRunner } from 'nest-commander';
import { TasksMaintenanceService } from '../../tasks/tasks-maintenance.service';
export declare class TasksResetStuckCommand extends CommandRunner {
    private tasksMaintenance;
    constructor(tasksMaintenance: TasksMaintenanceService);
    run(): Promise<void>;
}

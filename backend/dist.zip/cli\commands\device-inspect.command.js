"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.DeviceInspectCommand = void 0;
const nest_commander_1 = require("nest-commander");
const prisma_service_1 = require("../../common/prisma.service");
let DeviceInspectCommand = class DeviceInspectCommand extends nest_commander_1.CommandRunner {
    constructor(prisma) {
        super();
        this.prisma = prisma;
    }
    async run(passedParams) {
        const [serial] = passedParams;
        if (!serial) {
            console.error('Uso: pnpm cli device:inspect <serial>');
            return;
        }
        const device = await this.prisma.device.findUnique({
            where: { serial },
            include: { model: true, tasks: { orderBy: { createdAt: 'desc' }, take: 10 } },
        });
        if (!device) {
            console.error(`Device com serial "${serial}" não encontrado`);
            return;
        }
        const params = device.parameters || {};
        const discovered = device.discoveredPaths || [];
        const unsupported = device.model?.unsupportedParameters || [];
        console.log(`\n=== ${device.serial} (${device.manufacturer} ${device.modelName}) ===`);
        console.log(`Status: ${device.status} | Último Inform: ${device.lastContact}`);
        console.log(`Modelo: ${device.model?.name ?? '(nenhum)'} | dataModel: ${device.model?.dataModel ?? '-'}`);
        console.log(`Homologação: ${device.model?.homologationStatus ?? '-'}`);
        console.log(`Parâmetros em cache: ${Object.keys(params).length} | Paths descobertos: ${discovered.length}`);
        console.log(`Unsupported paths: ${unsupported.length}`);
        if (unsupported.length > 0) {
            for (const p of unsupported.slice(0, 10)) {
                console.log(`  ✗ ${p}`);
            }
            if (unsupported.length > 10)
                console.log(`  ... e mais ${unsupported.length - 10}`);
        }
        console.log(`\n--- Últimas 10 tasks ---`);
        for (const t of device.tasks) {
            const err = t.error ? ` err=${t.error.slice(0, 60)}` : '';
            console.log(`[${t.status}] ${t.type} (${t.attempts}/${t.maxAttempts})${err} — ${t.createdAt.toISOString()}`);
        }
    }
};
exports.DeviceInspectCommand = DeviceInspectCommand;
exports.DeviceInspectCommand = DeviceInspectCommand = __decorate([
    (0, nest_commander_1.Command)({ name: 'device:inspect', description: 'Mostra status, parâmetros e tasks de um device' }),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService])
], DeviceInspectCommand);
//# sourceMappingURL=device-inspect.command.js.map
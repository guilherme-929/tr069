import { AlertsService } from './alerts.service';
export declare class AlertsController {
    private alertsService;
    constructor(alertsService: AlertsService);
    findAll(tenantId: string, query: any): Promise<{
        data: ({
            device: {
                serial: string;
                modelName: string;
            } | null;
        } & {
            id: string;
            tenantId: string;
            createdAt: Date;
            updatedAt: Date;
            resolved: boolean;
            type: import(".prisma/client").$Enums.AlertType;
            severity: import(".prisma/client").$Enums.AlertSeverity;
            title: string;
            message: string | null;
            deviceId: string | null;
            read: boolean;
        })[];
        total: number;
        page: number;
        limit: number;
        totalPages: number;
    }>;
    resolve(id: string): Promise<{
        id: string;
        tenantId: string;
        createdAt: Date;
        updatedAt: Date;
        resolved: boolean;
        type: import(".prisma/client").$Enums.AlertType;
        severity: import(".prisma/client").$Enums.AlertSeverity;
        title: string;
        message: string | null;
        deviceId: string | null;
        read: boolean;
    }>;
}

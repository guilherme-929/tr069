export declare class AcsModule {
}

"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.DiscoveryEngineModule = void 0;
const common_1 = require("@nestjs/common");
const declare_service_1 = require("./declare.service");
const prisma_service_1 = require("../common/prisma.service");
let DiscoveryEngineModule = class DiscoveryEngineModule {
};
exports.DiscoveryEngineModule = DiscoveryEngineModule;
exports.DiscoveryEngineModule = DiscoveryEngineModule = __decorate([
    (0, common_1.Module)({
        providers: [declare_service_1.DeclareService, prisma_service_1.PrismaService],
        exports: [declare_service_1.DeclareService],
    })
], DiscoveryEngineModule);
//# sourceMappingURL=discovery-engine.module.js.map
"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.FirmwareService = void 0;
const common_1 = require("@nestjs/common");
const prisma_service_1 = require("../common/prisma.service");
let FirmwareService = class FirmwareService {
    constructor(prisma) {
        this.prisma = prisma;
    }
    async findAll(tenantId, query) {
        const page = query.page || 1;
        const limit = query.limit || 20;
        const skip = (page - 1) * limit;
        const where = { tenantId };
        if (query.modelId)
            where.modelId = query.modelId;
        const [data, total] = await Promise.all([
            this.prisma.firmware.findMany({
                where, skip, take: limit, orderBy: { createdAt: 'desc' },
                include: { model: true, _count: { select: { devices: true } } },
            }),
            this.prisma.firmware.count({ where }),
        ]);
        return { data, total, page, limit, totalPages: Math.ceil(total / limit) };
    }
    async findOne(id) {
        const firmware = await this.prisma.firmware.findUnique({
            where: { id },
            include: { model: true },
        });
        if (!firmware)
            throw new common_1.NotFoundException('Firmware not found');
        return firmware;
    }
    async create(data, tenantId) {
        return this.prisma.firmware.create({ data: { ...data, tenantId } });
    }
    async update(id, data) {
        const firmware = await this.prisma.firmware.findUnique({ where: { id } });
        if (!firmware)
            throw new common_1.NotFoundException('Firmware not found');
        return this.prisma.firmware.update({ where: { id }, data });
    }
    async remove(id) {
        const firmware = await this.prisma.firmware.findUnique({ where: { id } });
        if (!firmware)
            throw new common_1.NotFoundException('Firmware not found');
        await this.prisma.firmware.delete({ where: { id } });
        return { message: 'Firmware removed' };
    }
};
exports.FirmwareService = FirmwareService;
exports.FirmwareService = FirmwareService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService])
], FirmwareService);
//# sourceMappingURL=firmware.service.js.map
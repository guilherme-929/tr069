import { PrismaService } from '../common/prisma.service';
import { WebsocketGateway } from '../websocket/websocket.gateway';
import { AlertSeverity, AlertType } from '@prisma/client';
export declare class AlertsService {
    private prisma;
    private ws;
    private readonly logger;
    constructor(prisma: PrismaService, ws: WebsocketGateway);
    findAll(tenantId: string, query: {
        page?: number;
        limit?: number;
        resolved?: string;
        severity?: string;
    }): Promise<{
        data: ({
            device: {
                serial: string;
                modelName: string;
            } | null;
        } & {
            id: string;
            tenantId: string;
            createdAt: Date;
            updatedAt: Date;
            resolved: boolean;
            type: import(".prisma/client").$Enums.AlertType;
            severity: import(".prisma/client").$Enums.AlertSeverity;
            title: string;
            message: string | null;
            deviceId: string | null;
            read: boolean;
        })[];
        total: number;
        page: number;
        limit: number;
        totalPages: number;
    }>;
    resolve(id: string): Promise<{
        id: string;
        tenantId: string;
        createdAt: Date;
        updatedAt: Date;
        resolved: boolean;
        type: import(".prisma/client").$Enums.AlertType;
        severity: import(".prisma/client").$Enums.AlertSeverity;
        title: string;
        message: string | null;
        deviceId: string | null;
        read: boolean;
    }>;
    create(data: {
        type: AlertType;
        severity: AlertSeverity;
        title: string;
        message?: string;
        deviceId?: string;
        tenantId: string;
    }): Promise<{
        id: string;
        tenantId: string;
        createdAt: Date;
        updatedAt: Date;
        resolved: boolean;
        type: import(".prisma/client").$Enums.AlertType;
        severity: import(".prisma/client").$Enums.AlertSeverity;
        title: string;
        message: string | null;
        deviceId: string | null;
        read: boolean;
    }>;
    checkOfflineDevices(): Promise<void>;
    checkOldFirmware(): Promise<void>;
}

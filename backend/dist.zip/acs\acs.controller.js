"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AcsController = void 0;
const common_1 = require("@nestjs/common");
const swagger_1 = require("@nestjs/swagger");
const acs_service_1 = require("./acs.service");
const cwmp_service_1 = require("./cwmp.service");
const jwt_auth_guard_1 = require("../auth/jwt-auth.guard");
const roles_guard_1 = require("../common/roles.guard");
const roles_decorator_1 = require("../common/roles.decorator");
const current_user_decorator_1 = require("../common/current-user.decorator");
const client_1 = require("@prisma/client");
const public_decorator_1 = require("../auth/public.decorator");
let AcsController = class AcsController {
    constructor(acsService, cwmpService) {
        this.acsService = acsService;
        this.cwmpService = cwmpService;
    }
    async handleCwmp(body, req, res) {
        const clientIp = req.headers['x-forwarded-for']?.split(',')[0]?.trim()
            || req.headers['x-real-ip']
            || req.ip
            || req.connection?.remoteAddress
            || '';
        const xmlResponse = await this.cwmpService.handleCwmp(body || '', undefined, undefined, clientIp);
        res.type('text/xml').send(xmlResponse);
    }
    getStats(tenantId) {
        return this.acsService.getDashboardStats(tenantId);
    }
    getProvisioningPerHour(tenantId) {
        return this.acsService.getProvisioningPerHour(tenantId);
    }
    getNetworkAvailability(tenantId) {
        return this.acsService.getNetworkAvailability(tenantId);
    }
    connectionRequest(id) {
        return this.acsService.sendConnectionRequest(id);
    }
    reboot(id) {
        return this.cwmpService.handleReboot(id);
    }
    factoryReset(id) {
        return this.cwmpService.handleFactoryReset(id);
    }
    async updateFirmware(id) {
        return this.cwmpService.handleFirmwareUpdate(id);
    }
    download(id, data) {
        return this.cwmpService.handleDownload(id, data.url, data.fileType);
    }
    getParameters(id, body) {
        return this.cwmpService.handleGetParameterValues(id, body.names);
    }
    setParameters(id, body) {
        return this.cwmpService.handleSetParameterValues(id, body.params);
    }
    setWiFi(id, body) {
        return this.cwmpService.handleSetWiFiConfig(id, body);
    }
    enableWiFi(id, body) {
        return this.cwmpService.handleSetWiFiEnable(id, body);
    }
    readWiFi(id) {
        return this.cwmpService.handleReadWiFiConfig(id);
    }
    fetchAll(id, body) {
        return this.cwmpService.handleFetchAllParams(id, body?.names);
    }
    discover(id) {
        return this.cwmpService.handleDiscover(id);
    }
    getConnectedDevices(id) {
        return this.cwmpService.handleGetConnectedDevices(id);
    }
    discoverStatus(id) {
        return this.cwmpService.handleGetDiscoveryStatus(id);
    }
};
exports.AcsController = AcsController;
__decorate([
    (0, public_decorator_1.Public)(),
    (0, common_1.Post)('cwmp'),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, common_1.Req)()),
    __param(2, (0, common_1.Res)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object, Object]),
    __metadata("design:returntype", Promise)
], AcsController.prototype, "handleCwmp", null);
__decorate([
    (0, swagger_1.ApiBearerAuth)(),
    (0, common_1.UseGuards)(jwt_auth_guard_1.JwtAuthGuard, roles_guard_1.RolesGuard),
    (0, roles_decorator_1.Roles)(client_1.Role.ADMIN, client_1.Role.TECHNICIAN),
    (0, common_1.Get)('api/acs/stats'),
    __param(0, (0, current_user_decorator_1.CurrentUser)('tenantId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], AcsController.prototype, "getStats", null);
__decorate([
    (0, swagger_1.ApiBearerAuth)(),
    (0, common_1.UseGuards)(jwt_auth_guard_1.JwtAuthGuard, roles_guard_1.RolesGuard),
    (0, roles_decorator_1.Roles)(client_1.Role.ADMIN, client_1.Role.TECHNICIAN),
    (0, common_1.Get)('api/acs/provisioning-per-hour'),
    __param(0, (0, current_user_decorator_1.CurrentUser)('tenantId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], AcsController.prototype, "getProvisioningPerHour", null);
__decorate([
    (0, swagger_1.ApiBearerAuth)(),
    (0, common_1.UseGuards)(jwt_auth_guard_1.JwtAuthGuard, roles_guard_1.RolesGuard),
    (0, roles_decorator_1.Roles)(client_1.Role.ADMIN, client_1.Role.TECHNICIAN),
    (0, common_1.Get)('api/acs/network-availability'),
    __param(0, (0, current_user_decorator_1.CurrentUser)('tenantId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], AcsController.prototype, "getNetworkAvailability", null);
__decorate([
    (0, swagger_1.ApiBearerAuth)(),
    (0, common_1.UseGuards)(jwt_auth_guard_1.JwtAuthGuard, roles_guard_1.RolesGuard),
    (0, roles_decorator_1.Roles)(client_1.Role.ADMIN, client_1.Role.TECHNICIAN),
    (0, common_1.Post)('api/devices/:id/connection-request'),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], AcsController.prototype, "connectionRequest", null);
__decorate([
    (0, swagger_1.ApiBearerAuth)(),
    (0, common_1.UseGuards)(jwt_auth_guard_1.JwtAuthGuard, roles_guard_1.RolesGuard),
    (0, roles_decorator_1.Roles)(client_1.Role.ADMIN, client_1.Role.TECHNICIAN),
    (0, common_1.Post)('api/devices/:id/reboot'),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], AcsController.prototype, "reboot", null);
__decorate([
    (0, swagger_1.ApiBearerAuth)(),
    (0, common_1.UseGuards)(jwt_auth_guard_1.JwtAuthGuard, roles_guard_1.RolesGuard),
    (0, roles_decorator_1.Roles)(client_1.Role.ADMIN, client_1.Role.TECHNICIAN),
    (0, common_1.Post)('api/devices/:id/reset'),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], AcsController.prototype, "factoryReset", null);
__decorate([
    (0, swagger_1.ApiBearerAuth)(),
    (0, common_1.UseGuards)(jwt_auth_guard_1.JwtAuthGuard, roles_guard_1.RolesGuard),
    (0, roles_decorator_1.Roles)(client_1.Role.ADMIN, client_1.Role.TECHNICIAN),
    (0, common_1.Post)('api/devices/:id/update'),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], AcsController.prototype, "updateFirmware", null);
__decorate([
    (0, swagger_1.ApiBearerAuth)(),
    (0, common_1.UseGuards)(jwt_auth_guard_1.JwtAuthGuard, roles_guard_1.RolesGuard),
    (0, roles_decorator_1.Roles)(client_1.Role.ADMIN, client_1.Role.TECHNICIAN),
    (0, common_1.Post)('api/devices/:id/download'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], AcsController.prototype, "download", null);
__decorate([
    (0, swagger_1.ApiBearerAuth)(),
    (0, common_1.UseGuards)(jwt_auth_guard_1.JwtAuthGuard, roles_guard_1.RolesGuard),
    (0, roles_decorator_1.Roles)(client_1.Role.ADMIN, client_1.Role.TECHNICIAN),
    (0, common_1.Post)('api/devices/:id/parameters'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], AcsController.prototype, "getParameters", null);
__decorate([
    (0, swagger_1.ApiBearerAuth)(),
    (0, common_1.UseGuards)(jwt_auth_guard_1.JwtAuthGuard, roles_guard_1.RolesGuard),
    (0, roles_decorator_1.Roles)(client_1.Role.ADMIN, client_1.Role.TECHNICIAN),
    (0, common_1.Put)('api/devices/:id/parameters'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], AcsController.prototype, "setParameters", null);
__decorate([
    (0, swagger_1.ApiBearerAuth)(),
    (0, common_1.UseGuards)(jwt_auth_guard_1.JwtAuthGuard, roles_guard_1.RolesGuard),
    (0, roles_decorator_1.Roles)(client_1.Role.ADMIN, client_1.Role.TECHNICIAN),
    (0, common_1.Post)('api/devices/:id/wifi'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], AcsController.prototype, "setWiFi", null);
__decorate([
    (0, swagger_1.ApiBearerAuth)(),
    (0, common_1.UseGuards)(jwt_auth_guard_1.JwtAuthGuard, roles_guard_1.RolesGuard),
    (0, roles_decorator_1.Roles)(client_1.Role.ADMIN, client_1.Role.TECHNICIAN),
    (0, common_1.Post)('api/devices/:id/wifi/enable'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], AcsController.prototype, "enableWiFi", null);
__decorate([
    (0, swagger_1.ApiBearerAuth)(),
    (0, common_1.UseGuards)(jwt_auth_guard_1.JwtAuthGuard, roles_guard_1.RolesGuard),
    (0, roles_decorator_1.Roles)(client_1.Role.ADMIN, client_1.Role.TECHNICIAN),
    (0, common_1.Post)('api/devices/:id/wifi/read'),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], AcsController.prototype, "readWiFi", null);
__decorate([
    (0, swagger_1.ApiBearerAuth)(),
    (0, common_1.UseGuards)(jwt_auth_guard_1.JwtAuthGuard, roles_guard_1.RolesGuard),
    (0, roles_decorator_1.Roles)(client_1.Role.ADMIN, client_1.Role.TECHNICIAN),
    (0, common_1.Post)('api/devices/:id/fetch-all'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], AcsController.prototype, "fetchAll", null);
__decorate([
    (0, swagger_1.ApiBearerAuth)(),
    (0, common_1.UseGuards)(jwt_auth_guard_1.JwtAuthGuard, roles_guard_1.RolesGuard),
    (0, roles_decorator_1.Roles)(client_1.Role.ADMIN, client_1.Role.TECHNICIAN),
    (0, common_1.Post)('api/devices/:id/discover'),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], AcsController.prototype, "discover", null);
__decorate([
    (0, swagger_1.ApiBearerAuth)(),
    (0, common_1.UseGuards)(jwt_auth_guard_1.JwtAuthGuard, roles_guard_1.RolesGuard),
    (0, roles_decorator_1.Roles)(client_1.Role.ADMIN, client_1.Role.TECHNICIAN),
    (0, common_1.Get)('api/devices/:id/connected-devices'),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], AcsController.prototype, "getConnectedDevices", null);
__decorate([
    (0, swagger_1.ApiBearerAuth)(),
    (0, common_1.UseGuards)(jwt_auth_guard_1.JwtAuthGuard, roles_guard_1.RolesGuard),
    (0, roles_decorator_1.Roles)(client_1.Role.ADMIN, client_1.Role.TECHNICIAN),
    (0, common_1.Get)('api/devices/:id/discover/status'),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], AcsController.prototype, "discoverStatus", null);
exports.AcsController = AcsController = __decorate([
    (0, swagger_1.ApiTags)('ACS'),
    (0, common_1.Controller)(),
    __metadata("design:paramtypes", [acs_service_1.AcsService,
        cwmp_service_1.CwmpService])
], AcsController);
//# sourceMappingURL=acs.controller.js.map
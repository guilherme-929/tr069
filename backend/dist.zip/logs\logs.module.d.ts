export declare class LogsModule {
}

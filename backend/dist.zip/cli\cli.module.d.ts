export declare class CliModule {
}

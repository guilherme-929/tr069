"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AcsModule = void 0;
const common_1 = require("@nestjs/common");
const acs_controller_1 = require("./acs.controller");
const acs_service_1 = require("./acs.service");
const cwmp_service_1 = require("./cwmp.service");
const prisma_service_1 = require("../common/prisma.service");
const websocket_gateway_1 = require("../websocket/websocket.gateway");
const scripts_module_1 = require("../scripts/scripts.module");
const system_config_module_1 = require("../system-config/system-config.module");
const devices_module_1 = require("../devices/devices.module");
let AcsModule = class AcsModule {
};
exports.AcsModule = AcsModule;
exports.AcsModule = AcsModule = __decorate([
    (0, common_1.Module)({
        imports: [(0, common_1.forwardRef)(() => scripts_module_1.ScriptsModule), system_config_module_1.SystemConfigModule, (0, common_1.forwardRef)(() => devices_module_1.DevicesModule)],
        controllers: [acs_controller_1.AcsController],
        providers: [acs_service_1.AcsService, cwmp_service_1.CwmpService, prisma_service_1.PrismaService, websocket_gateway_1.WebsocketGateway],
        exports: [acs_service_1.AcsService, cwmp_service_1.CwmpService],
    })
], AcsModule);
//# sourceMappingURL=acs.module.js.map
"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.DeviceRefreshCommand = void 0;
const nest_commander_1 = require("nest-commander");
const prisma_service_1 = require("../../common/prisma.service");
const declare_service_1 = require("../../discovery-engine/declare.service");
let DeviceRefreshCommand = class DeviceRefreshCommand extends nest_commander_1.CommandRunner {
    constructor(prisma, declareService) {
        super();
        this.prisma = prisma;
        this.declareService = declareService;
    }
    parseMaxAge(val) {
        return parseInt(val, 10);
    }
    async run(passedParams, options) {
        const [serial, path] = passedParams;
        if (!serial || !path) {
            console.error('Uso: pnpm cli device:refresh <serial> "<path ou path.*>" [--max-age 3600000]');
            return;
        }
        const device = await this.prisma.device.findUnique({ where: { serial } });
        if (!device) {
            console.error(`Device "${serial}" não encontrado`);
            return;
        }
        const result = await this.declareService.declare(device.id, path, { maxAgeMs: options.maxAge });
        console.log(result);
    }
};
exports.DeviceRefreshCommand = DeviceRefreshCommand;
__decorate([
    (0, nest_commander_1.Option)({ flags: '--max-age <ms>', description: 'Idade máxima aceitável em ms antes de re-buscar (default 3600000)' }),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Number)
], DeviceRefreshCommand.prototype, "parseMaxAge", null);
exports.DeviceRefreshCommand = DeviceRefreshCommand = __decorate([
    (0, nest_commander_1.Command)({ name: 'device:refresh', description: 'Equivalente ao declare() do GenieACS: pede um path do CPE de forma segura' }),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService,
        declare_service_1.DeclareService])
], DeviceRefreshCommand);
//# sourceMappingURL=device-refresh.command.js.map
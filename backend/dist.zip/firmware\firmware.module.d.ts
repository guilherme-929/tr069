export declare class FirmwareModule {
}

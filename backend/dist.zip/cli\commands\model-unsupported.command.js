"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ModelUnsupportedCommand = void 0;
const nest_commander_1 = require("nest-commander");
const prisma_service_1 = require("../../common/prisma.service");
let ModelUnsupportedCommand = class ModelUnsupportedCommand extends nest_commander_1.CommandRunner {
    constructor(prisma) {
        super();
        this.prisma = prisma;
    }
    parseAdd(val) {
        return val;
    }
    parseClear() {
        return true;
    }
    parseTenant(val) {
        return val;
    }
    async run(args, options) {
        const [manufacturer, name] = args;
        const tenantId = options.tenant || (await this.resolveDefaultTenant());
        if (!tenantId) {
            console.error('No tenant found. Run seed first.');
            return;
        }
        const model = await this.prisma.deviceModel.findFirst({
            where: { manufacturer, name, tenantId },
        });
        if (!model) {
            console.log(`Model "${manufacturer} / ${name}" não encontrado.`);
            console.log('Crie com: POST /api/models');
            return;
        }
        if (options.clear) {
            await this.prisma.deviceModel.update({
                where: { id: model.id },
                data: { unsupportedParameters: [] },
            });
            console.log(`Unsupported parameters limpos para "${model.name}".`);
            return;
        }
        if (options.add) {
            const current = new Set(model.unsupportedParameters || []);
            current.add(options.add);
            await this.prisma.deviceModel.update({
                where: { id: model.id },
                data: { unsupportedParameters: Array.from(current) },
            });
            console.log(`Path "${options.add}" adicionado como unsupported em "${model.name}".`);
            return;
        }
        const unsupported = model.unsupportedParameters || [];
        console.log(`\nModelo: ${model.manufacturer} / ${model.name}`);
        console.log(`HW Version: ${model.hwVersion || 'N/A'}`);
        console.log(`Data Model: ${model.dataModel}`);
        console.log(`Homologação: ${model.homologationStatus}`);
        console.log(`\nUnsupported Parameters (${unsupported.length}):`);
        if (unsupported.length === 0) {
            console.log('  (nenhum)');
        }
        else {
            for (const p of unsupported) {
                console.log(`  - ${p}`);
            }
        }
    }
    async resolveDefaultTenant() {
        const tenant = await this.prisma.tenant.findFirst({ where: { slug: 'default-isp' } })
            || await this.prisma.tenant.findFirst();
        return tenant?.id || null;
    }
};
exports.ModelUnsupportedCommand = ModelUnsupportedCommand;
__decorate([
    (0, nest_commander_1.Option)({
        flags: '--add <path>',
        description: 'Adiciona um path como unsupported',
    }),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], ModelUnsupportedCommand.prototype, "parseAdd", null);
__decorate([
    (0, nest_commander_1.Option)({
        flags: '--clear',
        description: 'Limpa todos os unsupported paths',
    }),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", void 0)
], ModelUnsupportedCommand.prototype, "parseClear", null);
__decorate([
    (0, nest_commander_1.Option)({
        flags: '--tenant <id>',
        description: 'Tenant ID (opcional)',
    }),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], ModelUnsupportedCommand.prototype, "parseTenant", null);
exports.ModelUnsupportedCommand = ModelUnsupportedCommand = __decorate([
    (0, nest_commander_1.Command)({
        name: 'model:unsupported',
        arguments: '<manufacturer> <name>',
        description: 'Gerencia paths unsupported de um modelo (listar/limpar/adicionar)',
    }),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService])
], ModelUnsupportedCommand);
//# sourceMappingURL=model-unsupported.command.js.map
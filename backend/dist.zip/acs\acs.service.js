"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var AcsService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.AcsService = void 0;
const common_1 = require("@nestjs/common");
const http = __importStar(require("http"));
const https = __importStar(require("https"));
const prisma_service_1 = require("../common/prisma.service");
const cwmp_service_1 = require("./cwmp.service");
const config_service_1 = require("../system-config/config.service");
let AcsService = AcsService_1 = class AcsService {
    constructor(prisma, cwmp, configService) {
        this.prisma = prisma;
        this.cwmp = cwmp;
        this.configService = configService;
        this.logger = new common_1.Logger(AcsService_1.name);
        this.serialByIp = new Map();
        this.cachedTenantId = null;
        this.sessionLogger = new common_1.Logger('CWMP-Session');
    }
    onModuleInit() {
        this.startAcsServer();
        this.resolveTenantId().catch(() => this.logger.warn('Could not pre-cache tenant ID'));
    }
    startAcsServer() {
        const port = parseInt(process.env.ACS_PORT || '7547', 10);
        this.server = http.createServer((req, res) => {
            this.handleCwmpRequest(req, res);
        });
        this.server.keepAliveTimeout = 120000;
        this.server.headersTimeout = 125000;
        this.server.listen(port, '0.0.0.0', () => {
            this.logger.log(`ACS CWMP Server listening on port ${port}`);
        });
    }
    async handleCwmpRequest(req, res) {
        if (!await this.validateAuth(req, res))
            return;
        let body = '';
        const sessionId = Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
        const rawClientIp = req.socket?.remoteAddress || req.headers['x-forwarded-for'] || '';
        const clientIp = rawClientIp.replace(/^::ffff:/, '');
        const sessionCtx = () => `[SID=${sessionId}]`;
        const slog = (msg) => this.sessionLogger.log(`${sessionCtx()} ${msg}`);
        req.on('data', (chunk) => (body += chunk));
        req.on('end', async () => {
            try {
                let serial = this.resolveDeviceSerial(req, body);
                const bodyLen = (body || '').length;
                const contentType = req.headers['content-type'] || '';
                const isSoap = contentType.includes('text/xml') || contentType.includes('application/soap') || body.includes('<soap:Envelope') || body.includes('<soapenv:Envelope') || body.includes('<SOAP-ENV:Envelope');
                if (!serial || serial === process.env.ACS_AUTH_USERNAME || serial === 'alemnet') {
                    serial = this.serialByIp.get(clientIp) || serial || '';
                }
                slog(`CWMP req serial=${serial || 'unknown'} ip=${clientIp} method=${req.method} contentType=${contentType} bodyLen=${bodyLen} isSoap=${isSoap}`);
                if (serial && isSoap && (body.includes('<Inform>') || body.includes('<cwmp:Inform>'))) {
                    this.serialByIp.set(clientIp, serial);
                }
                if (!body || body.trim().length === 0 || !isSoap) {
                    await this.handleCpeReady(serial || '', res);
                    return;
                }
                if (serial && (body.includes('<Inform>') || body.includes('<cwmp:Inform>'))) {
                    await this.failInProgressTasks(serial, 'New Inform â€” previous command abandoned by CPE');
                }
                const requestCwmpId = this.extractCwmpId(body);
                const xmlResponse = await this.cwmp.handleCwmp(body, serial || undefined, undefined, clientIp);
                const responseWithCorrectId = requestCwmpId
                    ? xmlResponse.replace(/(<cwmp:ID[^>]*>)[^<]+(<\/cwmp:ID>)/, `$1${requestCwmpId}$2`)
                    : xmlResponse;
                const isInformResponse = responseWithCorrectId.includes('InformResponse') || responseWithCorrectId.includes('cwmp:InformResponse');
                const isCommandResponse = responseWithCorrectId.includes('SetParameterValuesResponse') ||
                    responseWithCorrectId.includes('GetParameterValuesResponse') ||
                    responseWithCorrectId.includes('GetParameterNamesResponse') ||
                    responseWithCorrectId.includes('DownloadResponse');
                if (serial) {
                    await this.failStaleTasks(serial);
                }
                if (serial && isCommandResponse) {
                    const dev = await this.prisma.device.findUnique({ where: { serial } });
                    if (dev && await this.trySendNextTask(dev, res)) {
                        slog(`Next command sent to ${serial} after command response`);
                        return;
                    }
                }
                if (serial && isInformResponse) {
                    const dev = await this.prisma.device.findUnique({ where: { serial } });
                    if (dev) {
                        const params = dev.parameters || {};
                        const lastRespAt = params.__lastInformResponseAt
                            ? new Date(params.__lastInformResponseAt).getTime()
                            : 0;
                        const deviceInformInterval = params.PeriodicInformInterval
                            || params['Device.ManagementServer.PeriodicInformInterval']
                            || params['InternetGatewayDevice.ManagementServer.PeriodicInformInterval']
                            || '300';
                        const intervalSec = Math.max(60, Math.min(parseInt(deviceInformInterval, 10), 600)) * 1000;
                        const recentThreshold = Date.now() - Math.round(intervalSec * 0.5);
                        const isReconnection = lastRespAt > 0 && lastRespAt < recentThreshold;
                        if (isReconnection) {
                            slog(`Device ${serial} reconnected (DB flag, last response >5 min ago) â€” checking pending tasks`);
                            await this.clearLastInformResponseFlag(dev);
                            await this.failInProgressTasks(serial, 'Session interrupted by reconnection');
                            if (await this.trySendPendingTask(dev, res)) {
                                slog(`Pending task sent to reconnected device ${serial}`);
                                return;
                            }
                        }
                        else {
                            await this.setLastInformResponseFlag(dev);
                            const oldPending = await this.prisma.task.count({
                                where: { deviceId: dev.id, status: 'PENDING', createdAt: { lt: new Date(Date.now() - 30000) } },
                            });
                            if (oldPending > 0 && await this.trySendPendingTask(dev, res)) {
                                slog(`Old pending task sent to device ${serial} (inline fallback)`);
                                await this.clearLastInformResponseFlag(dev);
                                return;
                            }
                        }
                    }
                }
                if (serial && isInformResponse) {
                    const dev = await this.prisma.device.findUnique({ where: { serial } });
                    if (dev) {
                        const mpPending = await this.prisma.task.findFirst({
                            where: { deviceId: dev.id, status: 'PENDING' },
                            orderBy: { createdAt: 'asc' },
                        });
                        if (mpPending) {
                            const mpAttempts = (mpPending.attempts || 0) + 1;
                            const mpMaxAttempts = mpPending.maxAttempts || 5;
                            if (mpAttempts <= mpMaxAttempts) {
                                await this.prisma.task.update({
                                    where: { id: mpPending.id },
                                    data: { status: 'IN_PROGRESS', attempts: mpAttempts },
                                });
                                const mpCmdXml = await this.cwmp.buildCwmpCommand(mpPending, dev.id);
                                const mpBoundary = 'TR069-MIME-Boundary-' + Date.now().toString(36);
                                const crlf = String.fromCharCode(13, 10);
                                const mpCmdClean = mpCmdXml.replace(/^<\?xml[^>]*>\s*/, '');
                                const mpBody = '--' + mpBoundary + crlf
                                    + 'Content-Type: text/xml; charset=utf-8' + crlf
                                    + 'Content-Transfer-Encoding: 7bit' + crlf
                                    + crlf
                                    + responseWithCorrectId + crlf
                                    + '--' + mpBoundary + crlf
                                    + 'Content-Type: text/xml; charset=utf-8' + crlf
                                    + 'Content-Transfer-Encoding: 7bit' + crlf
                                    + crlf
                                    + mpCmdClean + crlf
                                    + '--' + mpBoundary + '--';
                                res.writeHead(200, {
                                    'Content-Type': 'multipart/mixed; boundary="' + mpBoundary + '"',
                                });
                                res.end(mpBody);
                                console.log('Multipart MIME sent to ' + serial);
                                return;
                            }
                        }
                    }
                }
                res.writeHead(200, {
                    'Content-Type': 'text/xml; charset=utf-8',
                    'SOAPServer': 'TR-069 ACS/1.0',
                });
                res.end(responseWithCorrectId);
                slog(`Response sent to ${serial || 'unknown'} (${responseWithCorrectId.length} bytes)`);
            }
            catch (error) {
                this.logger.error(`${sessionCtx()} CWMP Error: ${error.message}`);
                res.writeHead(500);
                res.end(`<error>${error.message}</error>`);
            }
        });
    }
    async trySendPendingTask(dev, res) {
        const pending = await this.prisma.task.findMany({
            where: { deviceId: dev.id, status: 'PENDING' },
            orderBy: { createdAt: 'asc' },
        });
        if (pending.length === 0)
            return false;
        const task = pending[0];
        const newAttempts = (task.attempts || 0) + 1;
        const maxAttempts = task.maxAttempts || 5;
        if (task.updatedAt) {
            const backoffMs = Math.min(1000 * Math.pow(2, newAttempts - 1), 300000);
            const elapsed = Date.now() - new Date(task.updatedAt).getTime();
            if (elapsed < backoffMs) {
                this.logger.debug(`Device ${dev.serial} â€” task "${task.type}" in backoff (${Math.round((backoffMs - elapsed) / 1000)}s remaining), skipping`);
                return false;
            }
        }
        if (newAttempts >= maxAttempts) {
            await this.prisma.task.update({
                where: { id: task.id },
                data: { status: 'FAILED', error: `Failed after ${maxAttempts} attempts (exponential backoff exhausted)`, attempts: newAttempts },
            });
            this.logger.warn(`Device ${dev.serial} â€” task "${task.type}" failed after ${newAttempts} attempts`);
            return false;
        }
        await this.prisma.task.update({
            where: { id: task.id },
            data: { status: 'IN_PROGRESS', attempts: newAttempts },
        });
        const commandXml = await this.cwmp.buildCwmpCommand(task, dev.id);
        this.logger.log(`Device ${dev.serial} â€” sending command "${task.type}" (attempt ${newAttempts}/${maxAttempts})`);
        res.writeHead(200, { 'Content-Type': 'text/xml; charset=utf-8' });
        res.end(commandXml);
        return true;
    }
    getBackoffMs(attempt) {
        const base = 1000;
        const max = 300000;
        const delay = Math.min(base * Math.pow(2, attempt - 1), max);
        return delay + Math.round(Math.random() * delay * 0.1);
    }
    async trySendNextTask(dev, res) {
        const remaining = await this.prisma.task.findMany({
            where: { deviceId: dev.id, status: 'PENDING' },
            orderBy: { createdAt: 'asc' },
        });
        if (remaining.length === 0)
            return false;
        const task = remaining[0];
        const newAttempts = (task.attempts || 0) + 1;
        const maxAttempts = task.maxAttempts || 5;
        if (task.updatedAt) {
            const backoffMs = this.getBackoffMs(newAttempts);
            const elapsed = Date.now() - new Date(task.updatedAt).getTime();
            if (elapsed < backoffMs) {
                this.logger.debug(`Device ${dev.serial} â€” task "${task.type}" in backoff (${Math.round((backoffMs - elapsed) / 1000)}s remaining), skipping`);
                return false;
            }
        }
        if (newAttempts >= maxAttempts) {
            await this.prisma.task.update({
                where: { id: task.id },
                data: { status: 'FAILED', error: `Failed after ${maxAttempts} attempts (exponential backoff exhausted)`, attempts: newAttempts },
            });
            this.logger.warn(`Device ${dev.serial} â€” task "${task.type}" failed after ${newAttempts} attempts`);
            return false;
        }
        await this.prisma.task.update({
            where: { id: task.id },
            data: { status: 'IN_PROGRESS', attempts: newAttempts },
        });
        const commandXml = await this.cwmp.buildCwmpCommand(task, dev.id);
        this.logger.log(`Sending next command "${task.type}" to device ${dev.serial} (attempt ${newAttempts}/${maxAttempts})`);
        res.writeHead(200, { 'Content-Type': 'text/xml; charset=utf-8' });
        res.end(commandXml);
        return true;
    }
    async setLastInformResponseFlag(dev) {
        const params = dev.parameters || {};
        params.__lastInformResponseAt = new Date().toISOString();
        await this.prisma.device.update({
            where: { id: dev.id },
            data: { parameters: params },
        });
        this.logger.log(`Device ${dev.serial} â€” set __lastInformResponseAt flag`);
    }
    async clearLastInformResponseFlag(dev) {
        const params = dev.parameters || {};
        delete params.__lastInformResponseAt;
        await this.prisma.device.update({
            where: { id: dev.id },
            data: { parameters: params },
        });
    }
    extractCwmpId(xml) {
        const match = xml.match(/<cwmp:ID[^>]*>([^<]+)<\/cwmp:ID>/);
        return match ? match[1] : null;
    }
    async failStaleTasks(serial) {
        const dev = await this.prisma.device.findUnique({ where: { serial } });
        if (!dev)
            return;
        const timeoutMinAgo = new Date(Date.now() - 15 * 60 * 1000);
        const stale = await this.prisma.task.findMany({
            where: {
                deviceId: dev.id,
                status: 'IN_PROGRESS',
                updatedAt: { lt: timeoutMinAgo },
            },
        });
        for (const t of stale) {
            await this.prisma.task.update({
                where: { id: t.id },
                data: { status: 'FAILED', error: 'Timed out waiting for CPE response' },
            });
            this.logger.warn(`Task "${t.type}" (${t.id}) stale â€” failed after 15 min`);
        }
    }
    async failInProgressTasks(serial, error) {
        const dev = await this.prisma.device.findUnique({ where: { serial } });
        if (!dev)
            return;
        const inProgress = await this.prisma.task.findMany({
            where: { deviceId: dev.id, status: 'IN_PROGRESS' },
        });
        for (const t of inProgress) {
            await this.prisma.task.update({
                where: { id: t.id },
                data: { status: 'FAILED', error },
            });
            this.logger.warn(`Task "${t.type}" (${t.id}) â€” ${error}`);
        }
    }
    resolveDeviceSerial(req, body) {
        try {
            if (body.includes('<Inform>') || body.includes('<cwmp:Inform>') || body.includes('<SOAP-ENV:Body')) {
                const serialMatch = body.match(/<SerialNumber>([^<]+)<\/SerialNumber>/);
                if (serialMatch)
                    return serialMatch[1];
            }
        }
        catch { }
        const authHeader = req.headers['authorization'];
        if (authHeader && authHeader.startsWith('Basic ')) {
            const base64 = authHeader.slice(6);
            const decoded = Buffer.from(base64, 'base64').toString('utf-8');
            const colonIndex = decoded.indexOf(':');
            if (colonIndex > 0)
                return decoded.slice(0, colonIndex);
        }
        return null;
    }
    async handleCpeReady(serial, res) {
        if (!serial) {
            res.writeHead(200, { 'Content-Type': 'text/xml' });
            res.end(this.cwmp.buildEmptySoapEnvelope());
            return;
        }
        const dev = await this.prisma.device.findUnique({ where: { serial } });
        if (dev) {
            const pendingTasks = await this.prisma.task.findMany({
                where: { deviceId: dev.id, status: 'PENDING' },
                orderBy: { createdAt: 'asc' },
            });
            if (pendingTasks.length > 0) {
                await this.trySendNextTask(dev, res);
                return;
            }
        }
        res.writeHead(200, { 'Content-Type': 'text/xml' });
        res.end(this.cwmp.buildEmptySoapEnvelope());
    }
    async resolveTenantId() {
        if (this.cachedTenantId)
            return this.cachedTenantId;
        const tenant = await this.prisma.tenant.findFirst({ where: { slug: 'default-isp' } })
            || await this.prisma.tenant.findFirst();
        if (!tenant)
            throw new Error('No tenant found. Run seed first.');
        this.cachedTenantId = tenant.id;
        return tenant.id;
    }
    async getEffectiveAcsUrl(deviceId) {
        const device = await this.prisma.device.findUnique({
            where: { id: deviceId },
            include: { tenant: true },
        });
        if (!device)
            throw new common_1.HttpException('Device not found', common_1.HttpStatus.NOT_FOUND);
        return device.acsPublicUrlOverride
            || device.tenant.acsPublicUrl
            || process.env.ACS_PUBLIC_URL
            || `http://${device.ipAddress || 'localhost'}:${process.env.ACS_PORT || '7547'}`;
    }
    async sendConnectionRequest(deviceId) {
        const device = await this.prisma.device.findUnique({
            where: { id: deviceId },
            include: { tenant: true },
        });
        if (!device)
            throw new common_1.HttpException('Device not found', common_1.HttpStatus.NOT_FOUND);
        if (!device.tenant.connectionRequestEnabled) {
            throw new common_1.HttpException('Connection requests are disabled for this tenant', common_1.HttpStatus.FORBIDDEN);
        }
        const targetUrl = device.connectionRequestUrl;
        if (!targetUrl) {
            throw new common_1.HttpException('No ConnectionRequest URL available for this device. The device may not have reported it yet.', common_1.HttpStatus.PRECONDITION_FAILED);
        }
        const username = device.connectionRequestUsername || device.serial;
        const password = device.connectionRequestPassword || device.serial;
        const auth = Buffer.from(`${username}:${password}`).toString('base64');
        const rawTimeout = await this.configService.getValue('default', 'cwmp.connectionRequestTimeout') || '2000';
        const timeoutMs = parseInt(rawTimeout, 10) || 2000;
        return new Promise((resolve, reject) => {
            const parsedUrl = new URL(targetUrl);
            const client = parsedUrl.protocol === 'https:' ? https : http;
            const options = {
                hostname: parsedUrl.hostname,
                port: parsedUrl.port,
                path: parsedUrl.pathname + parsedUrl.search,
                method: 'GET',
                timeout: timeoutMs,
                headers: {
                    'Authorization': `Basic ${auth}`,
                },
            };
            const req = client.request(options, (res) => {
                this.logger.log(`ConnectionRequest to ${targetUrl} responded with ${res.statusCode}`);
                const statusCode = res.statusCode;
                const is200 = statusCode === 200;
                const is202 = statusCode === 202;
                resolve({
                    success: statusCode < 500,
                    statusCode,
                    executedImmediately: is200,
                    queued: is202,
                    message: is200
                        ? `Connection request executed immediately (200): device will process tasks now`
                        : is202
                            ? `Connection request queued (202): device will process on next scheduled Inform`
                            : `Connection request sent. Response: ${statusCode} ${res.statusMessage}`,
                });
            });
            req.on('error', (err) => {
                this.logger.error(`ConnectionRequest to ${targetUrl} failed: ${err.message}`);
                reject(new common_1.HttpException(`Failed to send connection request: ${err.message}`, common_1.HttpStatus.SERVICE_UNAVAILABLE));
            });
            req.on('timeout', () => {
                req.destroy();
                reject(new common_1.HttpException('Connection request timed out after 10s', common_1.HttpStatus.GATEWAY_TIMEOUT));
            });
            req.end();
        });
    }
    async getDashboardStats(tenantId) {
        const [online, offline, totalDevices, totalModels, totalFirmwares, alerts] = await Promise.all([
            this.prisma.device.count({ where: { tenantId, status: 'ONLINE' } }),
            this.prisma.device.count({ where: { tenantId, status: { in: ['OFFLINE', 'ERROR'] } } }),
            this.prisma.device.count({ where: { tenantId } }),
            this.prisma.deviceModel.count({ where: { tenantId } }),
            this.prisma.firmware.count({ where: { tenantId } }),
            this.prisma.alert.findMany({ where: { tenantId, resolved: false }, orderBy: { createdAt: 'desc' }, take: 5 }),
        ]);
        const provisionedToday = await this.prisma.event.count({
            where: { tenantId, createdAt: { gte: new Date(new Date().setHours(0, 0, 0, 0)) } },
        });
        return { online, offline, totalDevices, totalModels, totalFirmwares, provisionedToday, alerts };
    }
    async getProvisioningPerHour(tenantId) {
        const since = new Date(Date.now() - 24 * 60 * 60 * 1000);
        const events = await this.prisma.event.findMany({
            where: { tenantId, createdAt: { gte: since } },
            select: { createdAt: true },
        });
        const buckets = {};
        for (let i = 0; i < 24; i++) {
            const h = new Date(Date.now() - i * 60 * 60 * 1000);
            const key = h.toISOString().slice(0, 13) + ':00';
            buckets[key] = 0;
        }
        for (const ev of events) {
            const key = new Date(ev.createdAt).toISOString().slice(0, 13) + ':00';
            if (buckets[key] !== undefined)
                buckets[key]++;
        }
        return Object.entries(buckets)
            .sort(([a], [b]) => a.localeCompare(b))
            .map(([hour, count]) => ({ hour, count }));
    }
    async getNetworkAvailability(tenantId) {
        const since = new Date(Date.now() - 24 * 60 * 60 * 1000);
        const onlineCounts = await this.prisma.device.count({ where: { tenantId, status: 'ONLINE' } });
        const totalCounts = await this.prisma.device.count({ where: { tenantId } });
        const events = await this.prisma.event.findMany({
            where: { tenantId, createdAt: { gte: since } },
            select: { createdAt: true, code: true },
        });
        const hourlyBuckets = {};
        for (let i = 0; i < 24; i++) {
            const h = new Date(Date.now() - i * 60 * 60 * 1000);
            const key = h.toISOString().slice(0, 13) + ':00';
            hourlyBuckets[key] = { total: totalCounts, online: 0 };
        }
        for (const ev of events) {
            const key = new Date(ev.createdAt).toISOString().slice(0, 13) + ':00';
            if (hourlyBuckets[key]) {
                hourlyBuckets[key].online++;
            }
        }
        return Object.entries(hourlyBuckets)
            .sort(([a], [b]) => a.localeCompare(b))
            .map(([hour, data]) => ({
            hour,
            availability: data.total > 0 ? Math.round((data.online / data.total) * 100) : 100,
        }));
    }
    async getDevicesList(tenantId, filters) {
        const page = filters.page || 1;
        const limit = filters.limit || 20;
        const skip = (page - 1) * limit;
        const where = { tenantId };
        if (filters.status)
            where.status = filters.status;
        if (filters.model)
            where.modelName = filters.model;
        if (filters.firmware)
            where.firmwareVersion = filters.firmware;
        if (filters.search) {
            where.OR = [
                { serial: { contains: filters.search, mode: 'insensitive' } },
                { mac: { contains: filters.search, mode: 'insensitive' } },
                { modelName: { contains: filters.search, mode: 'insensitive' } },
            ];
        }
        const [data, total] = await Promise.all([
            this.prisma.device.findMany({
                where, skip, take: limit,
                orderBy: { lastContact: 'desc' },
                include: { model: true, client: true, firmware: true },
            }),
            this.prisma.device.count({ where }),
        ]);
        return { data, total, page, limit, totalPages: Math.ceil(total / limit) };
    }
    async validateAuth(req, res) {
        const authHeader = req.headers['authorization'];
        if (!authHeader || !authHeader.startsWith('Basic ')) {
            res.writeHead(401, { 'WWW-Authenticate': 'Basic realm="TR-069 ACS"' });
            res.end('Unauthorized');
            return false;
        }
        const base64 = authHeader.slice(6);
        const decoded = Buffer.from(base64, 'base64').toString('utf-8');
        const colonIndex = decoded.indexOf(':');
        if (colonIndex === -1) {
            res.writeHead(401, { 'WWW-Authenticate': 'Basic realm="TR-069 ACS"' });
            res.end('Unauthorized');
            return false;
        }
        const username = decoded.slice(0, colonIndex);
        const password = decoded.slice(colonIndex + 1);
        const configUser = await this.configService.getValue('default', 'acs.default.username');
        const configPass = await this.configService.getValue('default', 'acs.default.password');
        const expectedUser = configUser || process.env.ACS_AUTH_USERNAME || 'alemnet';
        const expectedPass = configPass || process.env.ACS_AUTH_PASSWORD || 'alemnet';
        if (username !== expectedUser || password !== expectedPass) {
            this.logger.warn(`CWMP auth failed for user: ${username}`);
            res.writeHead(401, { 'WWW-Authenticate': 'Basic realm="TR-069 ACS"' });
            res.end('Unauthorized');
            return false;
        }
        return true;
    }
};
exports.AcsService = AcsService;
exports.AcsService = AcsService = AcsService_1 = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService,
        cwmp_service_1.CwmpService,
        config_service_1.ConfigService])
], AcsService);
//# sourceMappingURL=acs.service.js.map
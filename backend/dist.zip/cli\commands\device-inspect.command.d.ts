import { CommandRunner } from 'nest-commander';
import { PrismaService } from '../../common/prisma.service';
export declare class DeviceInspectCommand extends CommandRunner {
    private prisma;
    constructor(prisma: PrismaService);
    run(passedParams: string[]): Promise<void>;
}

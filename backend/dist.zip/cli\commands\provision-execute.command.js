"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ProvisionExecuteCommand = void 0;
const nest_commander_1 = require("nest-commander");
const prisma_service_1 = require("../../common/prisma.service");
const provisions_engine_service_1 = require("../../scripts/provisions-engine.service");
let ProvisionExecuteCommand = class ProvisionExecuteCommand extends nest_commander_1.CommandRunner {
    constructor(prisma, provisionsEngine) {
        super();
        this.prisma = prisma;
        this.provisionsEngine = provisionsEngine;
    }
    parseEvent(val) {
        return val.split(',').map((s) => s.trim());
    }
    async run(args, options) {
        const [name, deviceId] = args;
        const device = await this.prisma.device.findUnique({ where: { id: deviceId } });
        if (!device) {
            console.error('Device not found');
            return;
        }
        console.log(`Executando provision "${name}" em ${device.serial} (${deviceId})...`);
        const result = await this.provisionsEngine.executeProvisionScript(name, deviceId, device.tenantId, { eventCodes: options.event || [] });
        console.log(`Status: ${result.status}`);
        if (result.error)
            console.error(`Error: ${result.error}`);
        if (result.tasks)
            console.log(`Tasks: ${JSON.stringify(result.tasks, null, 2)}`);
        if (result.logs && result.logs.length > 0) {
            console.log('Logs:');
            for (const l of result.logs)
                console.log(`  ${l}`);
        }
    }
};
exports.ProvisionExecuteCommand = ProvisionExecuteCommand;
__decorate([
    (0, nest_commander_1.Option)({
        flags: '--event <codes>',
        description: 'Event codes (comma separated)',
    }),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], ProvisionExecuteCommand.prototype, "parseEvent", null);
exports.ProvisionExecuteCommand = ProvisionExecuteCommand = __decorate([
    (0, nest_commander_1.Command)({
        name: 'provision:execute',
        arguments: '<name> <deviceId>',
        description: 'Executa uma provision script em um device',
    }),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService,
        provisions_engine_service_1.ProvisionsEngineService])
], ProvisionExecuteCommand);
//# sourceMappingURL=provision-execute.command.js.map
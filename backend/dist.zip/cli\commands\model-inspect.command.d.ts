import { CommandRunner } from 'nest-commander';
import { PrismaService } from '../../common/prisma.service';
export declare class ModelInspectCommand extends CommandRunner {
    private prisma;
    constructor(prisma: PrismaService);
    run(args: string[]): Promise<void>;
}
